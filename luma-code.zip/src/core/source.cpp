#include "luma/core/source.hpp"

#include <fstream>
#include <iterator>
#include <stdexcept>

namespace luma
{

    std::string read_source_file(const std::filesystem::path &path)
    {
        std::ifstream input(path, std::ios::binary);
        if (!input)
        {
            throw std::runtime_error("Cannot open source file: " + path.string());
        }
        return {std::istreambuf_iterator<char>{input}, std::istreambuf_iterator<char>{}};
    }

}