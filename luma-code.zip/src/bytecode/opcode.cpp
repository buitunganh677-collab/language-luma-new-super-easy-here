#include "luma/bytecode/opcode.hpp"

namespace luma
{

    std::string_view opcode_name(OpCode opcode)
    {
        switch (opcode)
        {
        case OpCode::constant:
            return "constant";
        case OpCode::load_global:
            return "load_global";
        case OpCode::define_global:
            return "define_global";
        case OpCode::assign_global:
            return "assign_global";
        case OpCode::negate:
            return "negate";
        case OpCode::logical_not:
            return "not";
        case OpCode::add:
            return "add";
        case OpCode::subtract:
            return "subtract";
        case OpCode::multiply:
            return "multiply";
        case OpCode::divide:
            return "divide";
        case OpCode::modulo:
            return "modulo";
        case OpCode::equal:
            return "equal";
        case OpCode::not_equal:
            return "not_equal";
        case OpCode::less:
            return "less";
        case OpCode::less_equal:
            return "less_equal";
        case OpCode::greater:
            return "greater";
        case OpCode::greater_equal:
            return "greater_equal";
        case OpCode::logical_and:
            return "and";
        case OpCode::logical_or:
            return "or";
        case OpCode::print:
            return "print";
        case OpCode::pop:
            return "pop";
        case OpCode::make_list:
            return "make_list";
        case OpCode::index_get:
            return "index_get";
        case OpCode::index_set:
            return "index_set";
        case OpCode::make_function:
            return "make_function";
        case OpCode::call:
            return "call";
        case OpCode::return_value:
            return "return_value";
        case OpCode::jump_if_false:
            return "jump_if_false";
        case OpCode::jump:
            return "jump";
        case OpCode::begin_repeat:
            return "begin_repeat";
        case OpCode::repeat_next:
            return "repeat_next";
        case OpCode::begin_for:
            return "begin_for";
        case OpCode::for_next:
            return "for_next";
        case OpCode::pop_repeat:
            return "pop_repeat";
        case OpCode::pop_for:
            return "pop_for";
        case OpCode::halt:
            return "halt";
        }
        return "unknown";
    }

}