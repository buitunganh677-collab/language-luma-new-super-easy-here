#include "luma/bytecode/compiler.hpp"
#include "luma/core/diagnostic.hpp"
namespace luma {
Chunk Compiler::compile(const Program& p) {
    chunk_ = Chunk{};
    compile_block(p.statements);
    chunk_.emit(OpCode::halt, 0, 0, {1, 1});
    return std::move(chunk_);
}
void Compiler::compile_block(const StmtList& b) { for (const auto& s : b) compile_statement(*s); }
void Compiler::compile_when(const WhenStmt& s) {
    compile_expression(*s.condition);
    std::size_t else_j = chunk_.emit(OpCode::jump_if_false, 0, 0, s.location);
    compile_block(s.then_branch);
    if (s.otherwise_branch.empty()) { chunk_.patch(else_j, chunk_.instructions().size()); return; }
    std::size_t end_j = chunk_.emit(OpCode::jump, 0, 0, s.location);
    chunk_.patch(else_j, chunk_.instructions().size());
    compile_block(s.otherwise_branch);
    chunk_.patch(end_j, chunk_.instructions().size());
}
void Compiler::compile_statement(const Stmt& st) {
    if (const auto* v = dynamic_cast<const LetStmt*>(&st)) {
        compile_expression(*v->value);
        chunk_.emit(OpCode::define_global, chunk_.add_name(v->name), 0, st.location);
        return;
    }
    if (const auto* v = dynamic_cast<const AssignStmt*>(&st)) {
        compile_expression(*v->value);
        chunk_.emit(OpCode::assign_global, chunk_.add_name(v->name), 0, st.location);
        return;
    }
    if (const auto* v = dynamic_cast<const ShowStmt*>(&st)) {
        compile_expression(*v->value);
        chunk_.emit(OpCode::print, 0, 0, st.location);
        return;
    }
    if (const auto* v = dynamic_cast<const ExprStmt*>(&st)) {
        compile_expression(*v->value);
        chunk_.emit(OpCode::pop, 0, 0, st.location);
        return;
    }
    if (const auto* v = dynamic_cast<const WhenStmt*>(&st)) { compile_when(*v); return; }
    if (const auto* v = dynamic_cast<const RepeatStmt*>(&st)) {
        compile_expression(*v->count);
        std::size_t begin = chunk_.emit(OpCode::begin_repeat, 0, 0, st.location);
        loops_.push_back({LoopContext::Kind::repeat_loop, {}, {}});
        compile_block(v->body);
        std::size_t next = chunk_.emit(OpCode::repeat_next, begin, 0, st.location);
        std::size_t exit = chunk_.instructions().size();
        chunk_.patch(begin, exit);
        for (std::size_t jump : loops_.back().break_jumps) chunk_.patch(jump, exit);
        for (std::size_t jump : loops_.back().continue_jumps) chunk_.patch(jump, next);
        loops_.pop_back();
        return;
    }
    if (const auto* v = dynamic_cast<const WhileStmt*>(&st)) {
        std::size_t top = chunk_.instructions().size();
        compile_expression(*v->condition);
        std::size_t exit_j = chunk_.emit(OpCode::jump_if_false, 0, 0, st.location);
        loops_.push_back({LoopContext::Kind::while_loop, {}, {}});
        compile_block(v->body);
        chunk_.emit(OpCode::jump, top, 0, st.location);
        std::size_t exit = chunk_.instructions().size();
        chunk_.patch(exit_j, exit);
        for (std::size_t jump : loops_.back().break_jumps) chunk_.patch(jump, exit);
        for (std::size_t jump : loops_.back().continue_jumps) chunk_.patch(jump, top);
        loops_.pop_back();
        return;
    }
    if (const auto* v = dynamic_cast<const ForStmt*>(&st)) {
        compile_expression(*v->iterable);
        std::size_t begin = chunk_.emit(OpCode::begin_for, chunk_.add_name(v->name), 0, st.location);
        loops_.push_back({LoopContext::Kind::for_loop, {}, {}});
        compile_block(v->body);
        std::size_t next = chunk_.emit(OpCode::for_next, begin, 0, st.location);
        std::size_t exit = chunk_.instructions().size();
        chunk_.patch_b(begin, exit);
        for (std::size_t jump : loops_.back().break_jumps) chunk_.patch(jump, exit);
        for (std::size_t jump : loops_.back().continue_jumps) chunk_.patch(jump, next);
        loops_.pop_back();
        return;
    }
    // Counting loop `for i in a to b step s:` -- compiled while-style: plain
    // counter/compare/add instructions, no list is ever built. `continue`
    // jumps to the increment, `break` jumps past the loop.
    if (const auto* v = dynamic_cast<const CountForStmt*>(&st)) {
        const std::string stop_name = "$stop" + std::to_string(temp_counter_);
        const std::string step_name = "$step" + std::to_string(temp_counter_);
        ++temp_counter_;

        compile_expression(*v->start);
        chunk_.emit(OpCode::define_global, chunk_.add_name(v->name), 0, st.location);
        compile_expression(*v->stop);
        chunk_.emit(OpCode::define_global, chunk_.add_name(stop_name), 0, st.location);
        compile_expression(*v->step);
        chunk_.emit(OpCode::define_global, chunk_.add_name(step_name), 0, st.location);

        const std::size_t zero_constant = chunk_.add_constant(Value{0.0});
        const std::size_t counter_index = chunk_.add_name(v->name);
        const std::size_t stop_index = chunk_.add_name(stop_name);
        const std::size_t step_index = chunk_.add_name(step_name);

        std::size_t top = chunk_.instructions().size();
        // (step > 0 and i <= stop) or (step < 0 and i >= stop)
        chunk_.emit(OpCode::load_global, step_index, 0, st.location);
        chunk_.emit(OpCode::constant, zero_constant, 0, st.location);
        chunk_.emit(OpCode::greater, 0, 0, st.location);
        chunk_.emit(OpCode::load_global, counter_index, 0, st.location);
        chunk_.emit(OpCode::load_global, stop_index, 0, st.location);
        chunk_.emit(OpCode::less_equal, 0, 0, st.location);
        chunk_.emit(OpCode::logical_and, 0, 0, st.location);
        chunk_.emit(OpCode::load_global, step_index, 0, st.location);
        chunk_.emit(OpCode::constant, zero_constant, 0, st.location);
        chunk_.emit(OpCode::less, 0, 0, st.location);
        chunk_.emit(OpCode::load_global, counter_index, 0, st.location);
        chunk_.emit(OpCode::load_global, stop_index, 0, st.location);
        chunk_.emit(OpCode::greater_equal, 0, 0, st.location);
        chunk_.emit(OpCode::logical_and, 0, 0, st.location);
        chunk_.emit(OpCode::logical_or, 0, 0, st.location);
        std::size_t exit_j = chunk_.emit(OpCode::jump_if_false, 0, 0, st.location);

        loops_.push_back({LoopContext::Kind::while_loop, {}, {}});
        compile_block(v->body);

        std::size_t increment = chunk_.instructions().size();
        chunk_.emit(OpCode::load_global, counter_index, 0, st.location);
        chunk_.emit(OpCode::load_global, step_index, 0, st.location);
        chunk_.emit(OpCode::add, 0, 0, st.location);
        chunk_.emit(OpCode::assign_global, counter_index, 0, st.location);
        chunk_.emit(OpCode::jump, top, 0, st.location);
        std::size_t exit = chunk_.instructions().size();
        chunk_.patch(exit_j, exit);
        for (std::size_t jump : loops_.back().break_jumps) chunk_.patch(jump, exit);
        for (std::size_t jump : loops_.back().continue_jumps) chunk_.patch(jump, increment);
        loops_.pop_back();
        return;
    }
    if (dynamic_cast<const BreakStmt*>(&st) != nullptr) {
        if (loops_.empty()) fail("'break' can only be used inside a loop", st.location);
        auto& loop = loops_.back();
        if (loop.kind == LoopContext::Kind::repeat_loop) chunk_.emit(OpCode::pop_repeat, 0, 0, st.location);
        if (loop.kind == LoopContext::Kind::for_loop) chunk_.emit(OpCode::pop_for, 0, 0, st.location);
        loop.break_jumps.push_back(chunk_.emit(OpCode::jump, 0, 0, st.location));
        return;
    }
    if (dynamic_cast<const ContinueStmt*>(&st) != nullptr) {
        if (loops_.empty()) fail("'continue' can only be used inside a loop", st.location);
        loops_.back().continue_jumps.push_back(chunk_.emit(OpCode::jump, 0, 0, st.location));
        return;
    }
    if (const auto* v = dynamic_cast<const IndexAssignStmt*>(&st)) {
        compile_expression(*v->base);
        compile_expression(*v->index);
        compile_expression(*v->value);
        chunk_.emit(OpCode::index_set, 0, 0, st.location);
        return;
    }
    if (dynamic_cast<const PassStmt*>(&st) != nullptr) return;
    if (dynamic_cast<const ImportStmt*>(&st) != nullptr)
        fail("'import' is only allowed at the top of a file", st.location);
    if (const auto* v = dynamic_cast<const FuncStmt*>(&st)) {
        Compiler sub; sub.compile_block(v->body);
        sub.chunk_.emit(OpCode::return_value, 0, 0, st.location);
        Chunk body = std::move(sub.chunk_);
        std::size_t fi = chunk_.add_function(v->parameters, std::move(body));
        chunk_.emit(OpCode::make_function, fi, 0, st.location);
        chunk_.emit(OpCode::define_global, chunk_.add_name(v->name), 0, st.location);
        return;
    }
    if (const auto* v = dynamic_cast<const ReturnStmt*>(&st)) {
        if (v->has_value()) compile_expression(*v->value);
        else chunk_.emit(OpCode::constant, chunk_.add_constant(Value{}), 0, st.location);
        chunk_.emit(OpCode::return_value, 0, 0, st.location);
        return;
    }
    fail("Cannot compile this statement", st.location);
}
void Compiler::compile_expression(const Expr& e) {
    if (const auto* v = dynamic_cast<const LiteralExpr*>(&e)) {
        chunk_.emit(OpCode::constant, chunk_.add_constant(v->value), 0, e.location); return;
    }
    if (const auto* v = dynamic_cast<const NameExpr*>(&e)) {
        chunk_.emit(OpCode::load_global, chunk_.add_name(v->name), 0, e.location); return;
    }
    if (const auto* v = dynamic_cast<const UnaryExpr*>(&e)) {
        compile_expression(*v->right);
        chunk_.emit(v->operation == TokenKind::minus ? OpCode::negate : OpCode::logical_not, 0, 0, e.location); return;
    }
    if (const auto* v = dynamic_cast<const BinaryExpr*>(&e)) {
        if (v->operation == TokenKind::and_keyword || v->operation == TokenKind::or_keyword) {
            compile_expression(*v->left); compile_expression(*v->right);
            chunk_.emit(v->operation == TokenKind::and_keyword ? OpCode::logical_and : OpCode::logical_or, 0, 0, e.location); return;
        }
        compile_expression(*v->left); compile_expression(*v->right);
        OpCode op = OpCode::add;
        switch (v->operation) {
        case TokenKind::plus: op = OpCode::add; break;
        case TokenKind::minus: op = OpCode::subtract; break;
        case TokenKind::star: op = OpCode::multiply; break;
        case TokenKind::slash: op = OpCode::divide; break;
        case TokenKind::percent: op = OpCode::modulo; break;
        case TokenKind::equal_equal: op = OpCode::equal; break;
        case TokenKind::bang_equal: op = OpCode::not_equal; break;
        case TokenKind::less: op = OpCode::less; break;
        case TokenKind::less_equal: op = OpCode::less_equal; break;
        case TokenKind::greater: op = OpCode::greater; break;
        case TokenKind::greater_equal: op = OpCode::greater_equal; break;
        default: fail("Cannot compile this operator", e.location);
        }
        chunk_.emit(op, 0, 0, e.location); return;
    }
    if (const auto *v = dynamic_cast<const CallExpr *>(&e)) {
        chunk_.emit(OpCode::load_global, chunk_.add_name(v->name), 0, e.location);
        for (const auto &a : v->arguments) compile_expression(*a);
        chunk_.emit(OpCode::call, v->arguments.size(), 0, e.location);
        return;
    }
    if (const auto *v = dynamic_cast<const ListExpr *>(&e)) {
        for (const auto &it : v->items) compile_expression(*it);
        chunk_.emit(OpCode::make_list, v->items.size(), 0, e.location);
        return;
    }
    if (const auto *v = dynamic_cast<const IndexExpr *>(&e)) {
        compile_expression(*v->base);
        compile_expression(*v->index);
        chunk_.emit(OpCode::index_get, 0, 0, e.location);
        return;
    }
    fail("Cannot compile this expression", e.location);
}
}
