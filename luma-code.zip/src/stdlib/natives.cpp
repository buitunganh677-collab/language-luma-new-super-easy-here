#include "luma/stdlib/natives.hpp"

#include <algorithm>
#include <cctype>
#include <chrono>
#include <cmath>
#include <fstream>
#include <iostream>
#include <random>
#include <sstream>
#include <stdexcept>
#include <thread>

#include "luma/stdlib/window.hpp"

namespace luma::stdlib
{
    namespace
    {

        [[noreturn]] void fail(const std::string &message)
        {
            throw std::runtime_error(message);
        }

        double num(const Value &value, const char *what)
        {
            if (!value.is_number())
                fail(std::string{what} + " needs a number, got " + value.type_name());
            return value.as_number();
        }

        int int_of(const Value &value, const char *what)
        {
            return static_cast<int>(num(value, what));
        }

        const std::string &text_of(const Value &value, const char *what)
        {
            if (!value.is_text())
                fail(std::string{what} + " needs text, got " + value.type_name());
            return value.as_text();
        }

        void check_arity(const std::string &name, const std::vector<Value> &arguments, std::size_t min_count,
                          std::size_t max_count)
        {
            if (arguments.size() < min_count || arguments.size() > max_count)
                fail(name + "() needs between " + std::to_string(min_count) + " and " + std::to_string(max_count) +
                     " argument(s), got " + std::to_string(arguments.size()));
        }

        NativePtr make(std::string name, std::size_t min_count, std::size_t max_count,
                       std::function<Value(std::vector<Value> &)> body)
        {
            auto record = std::make_shared<NativeRecord>();
            record->name = name;
            record->min_arguments = min_count;
            record->max_arguments = max_count;
            record->unlimited = false;
            record->call = [name, min_count, max_count, body](std::vector<Value> &arguments) -> Value {
                check_arity(name, arguments, min_count, max_count);
                return body(arguments);
            };
            return record;
        }

        std::unordered_map<std::string, Value> build_table()
        {
            std::unordered_map<std::string, Value> table;
            auto add = [&](std::string name, std::size_t min_count, std::size_t max_count,
                           std::function<Value(std::vector<Value> &)> body) {
                table.emplace(name, Value{make(name, min_count, max_count, std::move(body))});
            };

            add("length", 1, 1, [](std::vector<Value> &a) -> Value {
                if (a[0].is_list())
                    return Value{static_cast<double>(a[0].as_list().size())};
                if (a[0].is_text())
                    return Value{static_cast<double>(a[0].as_text().size())};
                fail("length() needs a list or text, got " + a[0].type_name());
            });
            add("text", 1, 1, [](std::vector<Value> &a) -> Value { return Value{a[0].display()}; });
            add("number", 1, 1, [](std::vector<Value> &a) -> Value {
                if (a[0].is_number())
                    return a[0];
                if (a[0].is_text())
                {
                    try
                    {
                        return Value{std::stod(a[0].as_text())};
                    }
                    catch (const std::exception &)
                    {
                        fail("number(\"" + a[0].as_text() + "\") is not a valid number");
                    }
                }
                fail("number() cannot convert a " + a[0].type_name());
            });
            add("type_of", 1, 1, [](std::vector<Value> &a) -> Value { return Value{a[0].type_name()}; });
            add("abs", 1, 1, [](std::vector<Value> &a) -> Value { return Value{std::fabs(num(a[0], "abs()"))}; });
            add("sqrt", 1, 1, [](std::vector<Value> &a) -> Value {
                const double value = num(a[0], "sqrt()");
                if (value < 0)
                    fail("sqrt() needs a non-negative number");
                return Value{std::sqrt(value)};
            });
            add("floor", 1, 1, [](std::vector<Value> &a) -> Value { return Value{std::floor(num(a[0], "floor()"))}; });
            add("ceil", 1, 1, [](std::vector<Value> &a) -> Value { return Value{std::ceil(num(a[0], "ceil()"))}; });
            add("round", 1, 1, [](std::vector<Value> &a) -> Value { return Value{std::round(num(a[0], "round()"))}; });
            add("pow", 2, 2, [](std::vector<Value> &a) -> Value {
                return Value{std::pow(num(a[0], "pow() base"), num(a[1], "pow() exponent"))};
            });
            add("min", 2, 2, [](std::vector<Value> &a) -> Value {
                return Value{std::min(num(a[0], "min()"), num(a[1], "min()"))};
            });
            add("max", 2, 2, [](std::vector<Value> &a) -> Value {
                return Value{std::max(num(a[0], "max()"), num(a[1], "max()"))};
            });
            add("random", 0, 0, [](std::vector<Value> &) -> Value {
                static std::mt19937 engine{std::random_device{}()};
                static std::uniform_real_distribution<double> distribution(0.0, 1.0);
                return Value{distribution(engine)};
            });
            add("push", 2, 2, [](std::vector<Value> &a) -> Value {
                if (!a[0].is_list())
                    fail("push() needs a list as its first argument, got " + a[0].type_name());
                a[0].as_list_ptr()->push_back(a[1]);
                return Value{};
            });
            add("pop", 1, 1, [](std::vector<Value> &a) -> Value {
                if (!a[0].is_list())
                    fail("pop() needs a list, got " + a[0].type_name());
                auto &items = *a[0].as_list_ptr();
                if (items.empty())
                    fail("pop() cannot take from an empty list");
                Value last = std::move(items.back());
                items.pop_back();
                return last;
            });
            add("reverse", 1, 1, [](std::vector<Value> &a) -> Value {
                if (!a[0].is_list())
                    fail("reverse() needs a list, got " + a[0].type_name());
                auto &items = *a[0].as_list_ptr();
                std::reverse(items.begin(), items.end());
                return Value{};
            });
            add("sort", 1, 1, [](std::vector<Value> &a) -> Value {
                if (!a[0].is_list())
                    fail("sort() needs a list, got " + a[0].type_name());
                auto &items = *a[0].as_list_ptr();
                std::sort(items.begin(), items.end(), [](const Value &left, const Value &right) {
                    if (left.is_number() && right.is_number())
                        return left.as_number() < right.as_number();
                    if (left.is_text() && right.is_text())
                        return left.as_text() < right.as_text();
                    fail("sort() needs a list of only numbers or only text");
                });
                return Value{};
            });
            add("range", 1, 3, [](std::vector<Value> &a) -> Value {
                const double start = a.size() >= 2 ? num(a[0], "range() start") : 0.0;
                const double stop = a.size() >= 2 ? num(a[1], "range() stop") : num(a[0], "range() stop");
                const double step = a.size() == 3 ? num(a[2], "range() step") : 1.0;
                if (step == 0)
                    fail("range() step cannot be 0");
                std::vector<Value> items;
                if (step > 0)
                    for (double value = start; value < stop; value += step)
                        items.push_back(Value{value});
                else
                    for (double value = start; value > stop; value += step)
                        items.push_back(Value{value});
                return Value{std::make_shared<std::vector<Value>>(std::move(items))};
            });
            // Backs the `for i in a to b [step s]:` loop -- both ends included.
            add("range_inclusive", 3, 3, [](std::vector<Value> &a) -> Value {
                const double start = num(a[0], "counting loop start");
                const double stop = num(a[1], "counting loop stop");
                const double step = num(a[2], "counting loop step");
                if (step == 0)
                    fail("The loop step cannot be 0");
                std::vector<Value> items;
                if (step > 0)
                    for (double value = start; value <= stop; value += step)
                        items.push_back(Value{value});
                else
                    for (double value = start; value >= stop; value += step)
                        items.push_back(Value{value});
                return Value{std::make_shared<std::vector<Value>>(std::move(items))};
            });
            add("join", 2, 2, [](std::vector<Value> &a) -> Value {
                if (!a[0].is_list())
                    fail("join() needs a list as its first argument, got " + a[0].type_name());
                const std::string &separator = text_of(a[1], "join() separator");
                std::string result;
                const auto &items = a[0].as_list();
                for (std::size_t index = 0; index < items.size(); ++index)
                {
                    if (index > 0)
                        result += separator;
                    result += items[index].display();
                }
                return Value{result};
            });
            add("split", 2, 2, [](std::vector<Value> &a) -> Value {
                const std::string &text = text_of(a[0], "split() text");
                const std::string &separator = text_of(a[1], "split() separator");
                std::vector<Value> pieces;
                if (separator.empty())
                {
                    for (const char character : text)
                        pieces.push_back(Value{std::string(1, character)});
                }
                else
                {
                    std::size_t start = 0;
                    while (true)
                    {
                        const auto found = text.find(separator, start);
                        if (found == std::string::npos)
                        {
                            pieces.push_back(Value{text.substr(start)});
                            break;
                        }
                        pieces.push_back(Value{text.substr(start, found - start)});
                        start = found + separator.size();
                    }
                }
                return Value{std::make_shared<std::vector<Value>>(std::move(pieces))};
            });
            add("upper", 1, 1, [](std::vector<Value> &a) -> Value {
                std::string text = text_of(a[0], "upper()");
                std::transform(text.begin(), text.end(), text.begin(),
                                [](unsigned char c) { return static_cast<char>(std::toupper(c)); });
                return Value{text};
            });
            add("lower", 1, 1, [](std::vector<Value> &a) -> Value {
                std::string text = text_of(a[0], "lower()");
                std::transform(text.begin(), text.end(), text.begin(),
                                [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
                return Value{text};
            });
            add("contains", 2, 2, [](std::vector<Value> &a) -> Value {
                if (a[0].is_list())
                {
                    const auto &items = a[0].as_list();
                    return Value{std::any_of(items.begin(), items.end(),
                                              [&](const Value &item) { return item == a[1]; })};
                }
                if (a[0].is_text())
                    return Value{a[0].as_text().find(text_of(a[1], "contains() needle")) != std::string::npos};
                fail("contains() needs a list or text as its first argument, got " + a[0].type_name());
            });
            add("find", 2, 2, [](std::vector<Value> &a) -> Value {
                if (a[0].is_list())
                {
                    const auto &items = a[0].as_list();
                    for (std::size_t index = 0; index < items.size(); ++index)
                        if (items[index] == a[1])
                            return Value{static_cast<double>(index)};
                    return Value{-1.0};
                }
                if (a[0].is_text())
                {
                    const auto found = a[0].as_text().find(text_of(a[1], "find() needle"));
                    return Value{found == std::string::npos ? -1.0 : static_cast<double>(found)};
                }
                fail("find() needs a list or text as its first argument, got " + a[0].type_name());
            });
            add("slice", 3, 3, [](std::vector<Value> &a) -> Value {
                const double raw_start = num(a[1], "slice() start");
                const double raw_stop = num(a[2], "slice() stop");
                const auto clamp_bound = [](double value, std::size_t size) {
                    if (value < 0)
                        return static_cast<std::size_t>(0);
                    if (value > static_cast<double>(size))
                        return size;
                    return static_cast<std::size_t>(value);
                };
                if (a[0].is_list())
                {
                    const auto &items = a[0].as_list();
                    const std::size_t start = clamp_bound(raw_start, items.size());
                    const std::size_t stop = clamp_bound(raw_stop, items.size());
                    std::vector<Value> result;
                    for (std::size_t index = start; index < stop; ++index)
                        result.push_back(items[index]);
                    return Value{std::make_shared<std::vector<Value>>(std::move(result))};
                }
                if (a[0].is_text())
                {
                    const auto &text = a[0].as_text();
                    const std::size_t start = clamp_bound(raw_start, text.size());
                    const std::size_t stop = clamp_bound(raw_stop, text.size());
                    return Value{start < stop ? text.substr(start, stop - start) : std::string{}};
                }
                fail("slice() needs a list or text as its first argument, got " + a[0].type_name());
            });
            add("sum", 1, 1, [](std::vector<Value> &a) -> Value {
                if (!a[0].is_list())
                    fail("sum() needs a list, got " + a[0].type_name());
                double total = 0;
                for (const auto &item : a[0].as_list())
                    total += num(item, "sum() item");
                return Value{total};
            });
            add("clamp", 3, 3, [](std::vector<Value> &a) -> Value {
                const double value = num(a[0], "clamp() value");
                const double low = num(a[1], "clamp() low");
                const double high = num(a[2], "clamp() high");
                return Value{std::min(std::max(value, low), high)};
            });
            add("trim", 1, 1, [](std::vector<Value> &a) -> Value {
                const std::string &text = text_of(a[0], "trim()");
                std::size_t begin = 0;
                std::size_t finish = text.size();
                while (begin < finish && std::isspace(static_cast<unsigned char>(text[begin])) != 0)
                    ++begin;
                while (finish > begin && std::isspace(static_cast<unsigned char>(text[finish - 1])) != 0)
                    --finish;
                return Value{text.substr(begin, finish - begin)};
            });
            add("replace", 3, 3, [](std::vector<Value> &a) -> Value {
                std::string text = text_of(a[0], "replace() text");
                const std::string &needle = text_of(a[1], "replace() old");
                const std::string &replacement = text_of(a[2], "replace() new");
                if (needle.empty())
                    return Value{text};
                std::size_t position = 0;
                while ((position = text.find(needle, position)) != std::string::npos)
                {
                    text.replace(position, needle.size(), replacement);
                    position += replacement.size();
                }
                return Value{text};
            });
            add("starts_with", 2, 2, [](std::vector<Value> &a) -> Value {
                const std::string &text = text_of(a[0], "starts_with() text");
                const std::string &prefix = text_of(a[1], "starts_with() prefix");
                return Value{text.size() >= prefix.size() && text.compare(0, prefix.size(), prefix) == 0};
            });
            add("ends_with", 2, 2, [](std::vector<Value> &a) -> Value {
                const std::string &text = text_of(a[0], "ends_with() text");
                const std::string &suffix = text_of(a[1], "ends_with() suffix");
                return Value{text.size() >= suffix.size() &&
                             text.compare(text.size() - suffix.size(), suffix.size(), suffix) == 0};
            });
            add("sleep_ms", 1, 1, [](std::vector<Value> &a) -> Value {
                const double milliseconds = num(a[0], "sleep_ms()");
                if (milliseconds > 0)
                    std::this_thread::sleep_for(std::chrono::milliseconds(static_cast<long long>(milliseconds)));
                return Value{};
            });
            add("now_ms", 0, 0, [](std::vector<Value> &) -> Value {
                const auto now = std::chrono::system_clock::now().time_since_epoch();
                return Value{static_cast<double>(std::chrono::duration_cast<std::chrono::milliseconds>(now).count())};
            });
            add("input", 0, 1, [](std::vector<Value> &a) -> Value {
                if (!a.empty())
                    std::cout << a[0].display() << std::flush;
                std::string line;
                if (!std::getline(std::cin, line))
                    return Value{};
                return Value{line};
            });
            add("read_file", 1, 1, [](std::vector<Value> &a) -> Value {
                const std::string &path = text_of(a[0], "read_file() path");
                std::ifstream stream(path, std::ios::binary);
                if (!stream)
                    fail("read_file() could not open '" + path + "'");
                std::ostringstream contents;
                contents << stream.rdbuf();
                return Value{contents.str()};
            });
            add("write_file", 2, 2, [](std::vector<Value> &a) -> Value {
                const std::string &path = text_of(a[0], "write_file() path");
                std::ofstream stream(path, std::ios::binary);
                if (!stream)
                    fail("write_file() could not open '" + path + "'");
                stream << a[1].display();
                return Value{};
            });

            add("window_open", 3, 3, [](std::vector<Value> &a) -> Value {
                return Value{static_cast<double>(window::open(text_of(a[0], "window_open() title"),
                                                               int_of(a[1], "window_open() width"),
                                                               int_of(a[2], "window_open() height")))};
            });
            add("window_should_close", 1, 1, [](std::vector<Value> &a) -> Value {
                return Value{window::should_close(int_of(a[0], "window_should_close() id"))};
            });
            add("window_clear", 4, 4, [](std::vector<Value> &a) -> Value {
                window::clear(int_of(a[0], "window_clear() id"), int_of(a[1], "red"), int_of(a[2], "green"),
                              int_of(a[3], "blue"));
                return Value{};
            });
            add("window_set_pixel", 6, 6, [](std::vector<Value> &a) -> Value {
                window::set_pixel(int_of(a[0], "window_set_pixel() id"), int_of(a[1], "x"), int_of(a[2], "y"),
                                  int_of(a[3], "red"), int_of(a[4], "green"), int_of(a[5], "blue"));
                return Value{};
            });
            add("window_fill_rect", 8, 8, [](std::vector<Value> &a) -> Value {
                window::fill_rect(int_of(a[0], "window_fill_rect() id"), int_of(a[1], "x"), int_of(a[2], "y"),
                                  int_of(a[3], "width"), int_of(a[4], "height"), int_of(a[5], "red"),
                                  int_of(a[6], "green"), int_of(a[7], "blue"));
                return Value{};
            });
            add("window_draw_line", 8, 8, [](std::vector<Value> &a) -> Value {
                window::draw_line(int_of(a[0], "window_draw_line() id"), int_of(a[1], "x1"), int_of(a[2], "y1"),
                                  int_of(a[3], "x2"), int_of(a[4], "y2"), int_of(a[5], "red"), int_of(a[6], "green"),
                                  int_of(a[7], "blue"));
                return Value{};
            });
            add("window_present", 1, 1, [](std::vector<Value> &a) -> Value {
                window::present(int_of(a[0], "window_present() id"));
                return Value{};
            });
            add("window_close", 1, 1, [](std::vector<Value> &a) -> Value {
                window::close(int_of(a[0], "window_close() id"));
                return Value{};
            });

            return table;
        }

    }

    const std::unordered_map<std::string, Value> &native_globals()
    {
        static const std::unordered_map<std::string, Value> table = build_table();
        return table;
    }

    Value call_native(const std::string &name, std::vector<Value> arguments)
    {
        const auto &table = native_globals();
        const auto found = table.find(name);
        if (found == table.end())
            fail("Unknown built-in function '" + name + "'");
        return found->second.as_native()->call(arguments);
    }

}
