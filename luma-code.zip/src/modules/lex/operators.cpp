#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor lex_operators() { return {"lex", "operators", "Recognizes operator lexemes"}; }
}