#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor lex_numbers() { return {"lex", "numbers", "Recognizes numeric literal grammar"}; }
}