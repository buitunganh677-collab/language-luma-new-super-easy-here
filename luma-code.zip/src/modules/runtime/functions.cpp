#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor runtime_functions() { return {"runtime", "functions", "Reserves user function runtime values"}; }
}