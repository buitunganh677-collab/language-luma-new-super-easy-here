#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor runtime_collections() { return {"runtime", "collections", "Reserves collection value semantics"}; }
}