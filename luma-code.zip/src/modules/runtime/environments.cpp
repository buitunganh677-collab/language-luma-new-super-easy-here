#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor runtime_environments() { return {"runtime", "environments", "Reserves lexical environment scopes"}; }
}