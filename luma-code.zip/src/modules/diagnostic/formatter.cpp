#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor diagnostic_formatter() { return {"diagnostic", "formatter", "Formats error payloads for users"}; }
}