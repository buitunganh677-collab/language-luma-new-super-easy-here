#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor diagnostic_renderer() { return {"diagnostic", "renderer", "Renders source-aware diagnostic output"}; }
}