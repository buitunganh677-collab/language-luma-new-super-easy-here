#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor diagnostic_severities() { return {"diagnostic", "severities", "Defines severity taxonomy"}; }
}