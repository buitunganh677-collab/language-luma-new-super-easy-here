#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor diagnostic_spans() { return {"diagnostic", "spans", "Defines source span semantics"}; }
}