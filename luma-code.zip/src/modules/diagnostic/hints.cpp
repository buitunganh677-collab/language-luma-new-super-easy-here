#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor diagnostic_hints() { return {"diagnostic", "hints", "Supplies actionable diagnostic hints"}; }
}