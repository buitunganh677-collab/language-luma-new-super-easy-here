#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor parse_blocks() { return {"parse", "blocks", "Parses indentation-scoped blocks"}; }
}