#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor parse_precedence() { return {"parse", "precedence", "Documents operator precedence rules"}; }
}