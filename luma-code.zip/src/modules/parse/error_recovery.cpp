#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor parse_error_recovery() { return {"parse", "error_recovery", "Reserves recoverable parse diagnostics"}; }
}