#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor parse_expressions() { return {"parse", "expressions", "Parses precedence-aware expressions"}; }
}