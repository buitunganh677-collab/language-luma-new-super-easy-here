#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor ast_validation() { return {"ast", "validation", "Reserves AST invariant checks"}; }
}