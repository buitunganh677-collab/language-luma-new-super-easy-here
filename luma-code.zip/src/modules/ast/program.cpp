#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor ast_program() { return {"ast", "program", "Owns program root representation"}; }
}