#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor ast_formatting() { return {"ast", "formatting", "Reserves syntax-aware formatting"}; }
}