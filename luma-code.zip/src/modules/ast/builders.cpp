#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor ast_builders() { return {"ast", "builders", "Constructs syntax nodes consistently"}; }
}