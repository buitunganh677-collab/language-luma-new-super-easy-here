#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor core_contracts() { return {"core", "contracts", "Documents cross-layer contracts"}; }
}