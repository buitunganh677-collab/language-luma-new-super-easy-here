#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor core_paths() { return {"core", "paths", "Normalizes source and module paths"}; }
}