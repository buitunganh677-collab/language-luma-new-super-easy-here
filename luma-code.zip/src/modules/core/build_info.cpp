#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor core_build_info() { return {"core", "build_info", "Exposes build metadata"}; }
}