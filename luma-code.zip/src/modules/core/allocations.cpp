#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor core_allocations() { return {"core", "allocations", "Defines allocation ownership boundaries"}; }
}