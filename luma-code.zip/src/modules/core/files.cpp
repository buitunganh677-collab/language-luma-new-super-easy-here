#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor core_files() { return {"core", "files", "Defines safe source file access"}; }
}