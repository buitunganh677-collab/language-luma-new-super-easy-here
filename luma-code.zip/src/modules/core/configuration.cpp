#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor core_configuration() { return {"core", "configuration", "Owns runtime configuration conventions"}; }
}