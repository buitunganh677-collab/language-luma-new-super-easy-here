#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor core_metrics() { return {"core", "metrics", "Defines runtime metric collection points"}; }
}