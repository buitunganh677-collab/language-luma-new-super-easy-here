#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor core_assertions() { return {"core", "assertions", "Captures internal invariant contracts"}; }
}