#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor stdlib_conversion() { return {"stdlib", "conversion", "Reserves explicit value conversions"}; }
}