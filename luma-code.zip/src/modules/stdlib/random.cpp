#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor stdlib_random() { return {"stdlib", "random", "Reserves deterministic random APIs"}; }
}