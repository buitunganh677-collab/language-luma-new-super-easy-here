#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor stdlib_math() { return {"stdlib", "math", "Reserves mathematical helper functions"}; }
}