#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor bytecode_writer() { return {"bytecode", "writer", "Writes compiled instruction chunks"}; }
}