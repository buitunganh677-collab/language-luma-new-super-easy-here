#include "luma/modules/catalog.hpp"

namespace luma::modules
{
    ModuleDescriptor bytecode_constants() { return {"bytecode", "constants", "Owns constant pool conventions"}; }
}