#include "luma/runtime/vm.hpp"

#include "luma/core/diagnostic.hpp"
#include "luma/runtime/ops.hpp"
#include "luma/stdlib/natives.hpp"

namespace luma
{

    VirtualMachine::VirtualMachine()
    {
        // Pre-size hot containers so typical programs never reallocate them.
        stack_.reserve(256);
        scopes_.reserve(16);
    }

    void VirtualMachine::run(const Chunk &chunk)
    {
        execute_chunk(chunk, stdlib::native_globals());
    }

    Value VirtualMachine::pop(const Instruction &instruction)
    {
        if (stack_.empty())
            runtime_error("Internal error: the value stack ran out unexpectedly", instruction);
        Value value = std::move(stack_.back());
        stack_.pop_back();
        return value;
    }

    void VirtualMachine::push(Value value) { stack_.push_back(std::move(value)); }

    void VirtualMachine::runtime_error(const std::string &message, const Instruction &instruction)
    {
        throw Diagnostic(message, instruction.location);
    }

    Value *VirtualMachine::find_variable(const std::string &name)
    {
        auto &current = scopes_.back();
        if (const auto found = current.find(name); found != current.end())
            return &found->second;
        if (scopes_.size() > 1)
        {
            auto &global = scopes_.front();
            if (const auto found = global.find(name); found != global.end())
                return &found->second;
        }
        return nullptr;
    }

    Value VirtualMachine::call_value(Value callee, std::vector<Value> arguments, const Instruction &instruction)
    {
        if (callee.is_native())
        {
            const auto &native = *callee.as_native();
            if (arguments.size() < native.min_arguments ||
                (!native.unlimited && arguments.size() > native.max_arguments))
                runtime_error("'" + native.name + "' was called with the wrong number of values", instruction);
            try
            {
                return native.call(arguments);
            }
            catch (const std::runtime_error &error)
            {
                runtime_error(error.what(), instruction);
            }
        }
        if (callee.is_function())
        {
            const auto &record = *callee.as_function();
            const auto &info = *record.info;
            if (arguments.size() != info.param_names.size())
                runtime_error("This function needs " + std::to_string(info.param_names.size()) +
                                  " value(s), got " + std::to_string(arguments.size()),
                              instruction);
            std::unordered_map<std::string, Value> parameters;
            for (std::size_t index = 0; index < info.param_names.size(); ++index)
                parameters[info.param_names[index]] = std::move(arguments[index]);
            return execute_chunk(info.body, std::move(parameters));
        }
        runtime_error("Cannot call a " + callee.type_name() + " like a function", instruction);
    }

    Value VirtualMachine::execute_chunk(const Chunk &chunk, std::unordered_map<std::string, Value> initial_scope)
    {
        scopes_.push_back(std::move(initial_scope));
        struct ScopeGuard
        {
            std::vector<std::unordered_map<std::string, Value>> &scopes;
            ~ScopeGuard() { scopes.pop_back(); }
        } guard{scopes_};

        const auto &instructions = chunk.instructions();
        std::vector<std::size_t> repeat_counts;
        std::vector<ForLoop> for_loops;
        std::size_t ip = 0;

        auto binary = [&](const Instruction &instruction, auto op) {
            Value right = pop(instruction);
            Value left = pop(instruction);
            try
            {
                push(op(left, right));
            }
            catch (const std::runtime_error &error)
            {
                runtime_error(error.what(), instruction);
            }
        };
        auto unary = [&](const Instruction &instruction, auto op) {
            Value value = pop(instruction);
            try
            {
                push(op(value));
            }
            catch (const std::runtime_error &error)
            {
                runtime_error(error.what(), instruction);
            }
        };

        while (ip < instructions.size())
        {
            const Instruction &instruction = instructions[ip];
            switch (instruction.opcode)
            {
            case OpCode::constant:
                push(chunk.constants().at(instruction.operand_a));
                ++ip;
                break;
            case OpCode::load_global:
            {
                const std::string &name = chunk.names().at(instruction.operand_a);
                Value *variable = find_variable(name);
                if (variable == nullptr)
                    runtime_error("I don't know a value named '" + name + "'", instruction);
                push(*variable);
                ++ip;
                break;
            }
            case OpCode::define_global:
                scopes_.back()[chunk.names().at(instruction.operand_a)] = pop(instruction);
                ++ip;
                break;
            case OpCode::assign_global:
            {
                Value value = pop(instruction);
                const std::string &name = chunk.names().at(instruction.operand_a);
                Value *variable = find_variable(name);
                if (variable == nullptr)
                    runtime_error("Cannot change '" + name + "' before it exists (use let first)", instruction);
                *variable = std::move(value);
                ++ip;
                break;
            }
            case OpCode::negate:
                unary(instruction, [](const Value &value) { return rt::negate(value); });
                ++ip;
                break;
            case OpCode::logical_not:
                unary(instruction, [](const Value &value) { return rt::logical_not(value); });
                ++ip;
                break;
            case OpCode::add:
                binary(instruction, [](const Value &l, const Value &r) { return rt::add(l, r); });
                ++ip;
                break;
            case OpCode::subtract:
                binary(instruction, [](const Value &l, const Value &r) { return rt::subtract(l, r); });
                ++ip;
                break;
            case OpCode::multiply:
                binary(instruction, [](const Value &l, const Value &r) { return rt::multiply(l, r); });
                ++ip;
                break;
            case OpCode::divide:
                binary(instruction, [](const Value &l, const Value &r) { return rt::divide(l, r); });
                ++ip;
                break;
            case OpCode::modulo:
                binary(instruction, [](const Value &l, const Value &r) { return rt::modulo(l, r); });
                ++ip;
                break;
            case OpCode::equal:
                binary(instruction, [](const Value &l, const Value &r) { return rt::equal(l, r); });
                ++ip;
                break;
            case OpCode::not_equal:
                binary(instruction, [](const Value &l, const Value &r) { return rt::not_equal(l, r); });
                ++ip;
                break;
            case OpCode::less:
                binary(instruction, [](const Value &l, const Value &r) { return rt::less(l, r); });
                ++ip;
                break;
            case OpCode::less_equal:
                binary(instruction, [](const Value &l, const Value &r) { return rt::less_equal(l, r); });
                ++ip;
                break;
            case OpCode::greater:
                binary(instruction, [](const Value &l, const Value &r) { return rt::greater(l, r); });
                ++ip;
                break;
            case OpCode::greater_equal:
                binary(instruction, [](const Value &l, const Value &r) { return rt::greater_equal(l, r); });
                ++ip;
                break;
            case OpCode::logical_and:
                binary(instruction, [](const Value &l, const Value &r) { return rt::logical_and(l, r); });
                ++ip;
                break;
            case OpCode::logical_or:
                binary(instruction, [](const Value &l, const Value &r) { return rt::logical_or(l, r); });
                ++ip;
                break;
            case OpCode::print:
                rt::show(pop(instruction));
                ++ip;
                break;
            case OpCode::pop:
                pop(instruction);
                ++ip;
                break;
            case OpCode::make_list:
            {
                std::vector<Value> items(instruction.operand_a);
                for (std::size_t index = instruction.operand_a; index-- > 0;)
                    items[index] = pop(instruction);
                push(rt::make_list(std::move(items)));
                ++ip;
                break;
            }
            case OpCode::index_get:
            {
                Value index = pop(instruction);
                Value base = pop(instruction);
                try
                {
                    push(rt::index_get(base, index));
                }
                catch (const std::runtime_error &error)
                {
                    runtime_error(error.what(), instruction);
                }
                ++ip;
                break;
            }
            case OpCode::index_set:
            {
                Value value = pop(instruction);
                Value index = pop(instruction);
                Value base = pop(instruction);
                try
                {
                    rt::index_set(base, index, std::move(value));
                }
                catch (const std::runtime_error &error)
                {
                    runtime_error(error.what(), instruction);
                }
                ++ip;
                break;
            }
            case OpCode::make_function:
            {
                auto record = std::make_shared<FunctionRecord>();
                record->info = chunk.functions().at(instruction.operand_a);
                push(Value{FunctionPtr{std::move(record)}});
                ++ip;
                break;
            }
            case OpCode::call:
            {
                std::vector<Value> arguments(instruction.operand_a);
                for (std::size_t index = instruction.operand_a; index-- > 0;)
                    arguments[index] = pop(instruction);
                Value callee = pop(instruction);
                push(call_value(std::move(callee), std::move(arguments), instruction));
                ++ip;
                break;
            }
            case OpCode::return_value:
                return pop(instruction);
            case OpCode::jump_if_false:
                ip = pop(instruction).truthy() ? ip + 1 : instruction.operand_a;
                break;
            case OpCode::jump:
                ip = instruction.operand_a;
                break;
            case OpCode::begin_repeat:
            {
                Value count_value = pop(instruction);
                if (!count_value.is_number())
                    runtime_error("repeat needs a number", instruction);
                const double count = count_value.as_number();
                if (count <= 0)
                    ip = instruction.operand_a;
                else
                {
                    repeat_counts.push_back(static_cast<std::size_t>(count));
                    ++ip;
                }
                break;
            }
            case OpCode::repeat_next:
            {
                std::size_t &remaining = repeat_counts.back();
                --remaining;
                if (remaining > 0)
                    ip = instruction.operand_a + 1;
                else
                {
                    repeat_counts.pop_back();
                    ++ip;
                }
                break;
            }
            case OpCode::begin_for:
            {
                Value iterable = pop(instruction);
                if (!iterable.is_list())
                    runtime_error("for ... in needs a list", instruction);
                if (iterable.as_list().empty())
                    ip = instruction.operand_b;
                else
                {
                    scopes_.back()[chunk.names().at(instruction.operand_a)] = iterable.as_list().front();
                    for_loops.push_back(ForLoop{iterable.as_list_ptr(), 0});
                    ++ip;
                }
                break;
            }
            case OpCode::for_next:
            {
                ForLoop &loop = for_loops.back();
                ++loop.index;
                if (loop.index < loop.list->size())
                {
                    const Instruction &begin_instruction = instructions.at(instruction.operand_a);
                    scopes_.back()[chunk.names().at(begin_instruction.operand_a)] = (*loop.list)[loop.index];
                    ip = instruction.operand_a + 1;
                }
                else
                {
                    for_loops.pop_back();
                    ++ip;
                }
                break;
            }
            case OpCode::pop_repeat:
                if (!repeat_counts.empty())
                    repeat_counts.pop_back();
                ++ip;
                break;
            case OpCode::pop_for:
                if (!for_loops.empty())
                    for_loops.pop_back();
                ++ip;
                break;
            case OpCode::halt:
                return Value{};
            }
        }
        return Value{};
    }

}
