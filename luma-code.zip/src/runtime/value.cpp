#include "luma/runtime/value.hpp"

#include <cmath>
#include <iomanip>
#include <sstream>
#include <utility>

namespace luma
{

    Value::Value(bool value) : storage_(value) {}
    Value::Value(double value) : storage_(value) {}
    Value::Value(std::string value) : storage_(std::move(value)) {}
    Value::Value(ListPtr value) : storage_(std::move(value)) {}
    Value::Value(FunctionPtr value) : storage_(std::move(value)) {}
    Value::Value(NativePtr value) : storage_(std::move(value)) {}

    const Value::Storage &Value::storage() const noexcept { return storage_; }

    bool Value::truthy() const
    {
        if (std::holds_alternative<std::monostate>(storage_))
            return false;
        if (const auto *value = std::get_if<bool>(&storage_))
            return *value;
        if (const auto *value = std::get_if<double>(&storage_))
            return *value != 0.0;
        if (const auto *value = std::get_if<std::string>(&storage_))
            return !value->empty();
        if (const auto *value = std::get_if<ListPtr>(&storage_))
            return !value->get()->empty();
        return true;
    }

    std::string Value::display() const
    {
        if (std::holds_alternative<std::monostate>(storage_))
            return "nothing";
        if (const auto *value = std::get_if<bool>(&storage_))
            return *value ? "true" : "false";
        if (const auto *value = std::get_if<double>(&storage_))
        {
            if (std::floor(*value) == *value && std::isfinite(*value))
                return std::to_string(static_cast<long long>(*value));
            std::ostringstream stream;
            stream << std::setprecision(15) << *value;
            return stream.str();
        }
        if (const auto *value = std::get_if<std::string>(&storage_))
            return *value;
        if (const auto *value = std::get_if<ListPtr>(&storage_))
        {
            std::string result = "[";
            const auto &items = *value->get();
            for (std::size_t index = 0; index < items.size(); ++index)
            {
                if (index > 0)
                    result += ", ";
                result += items[index].display();
            }
            result += "]";
            return result;
        }
        if (const auto *value = std::get_if<FunctionPtr>(&storage_))
        {
            static_cast<void>(value);
            return "<func>";
        }
        if (const auto *value = std::get_if<NativePtr>(&storage_))
            return "<func " + value->get()->name + ">";
        return "unknown";
    }

    std::string Value::type_name() const
    {
        if (std::holds_alternative<std::monostate>(storage_))
            return "nothing";
        if (std::holds_alternative<bool>(storage_))
            return "flag";
        if (std::holds_alternative<double>(storage_))
            return "number";
        if (std::holds_alternative<std::string>(storage_))
            return "text";
        if (std::holds_alternative<ListPtr>(storage_))
            return "list";
        return "func";
    }

    bool Value::is_number() const { return std::holds_alternative<double>(storage_); }
    double Value::as_number() const { return std::get<double>(storage_); }
    bool Value::is_list() const { return std::holds_alternative<ListPtr>(storage_); }
    const std::vector<Value> &Value::as_list() const { return *std::get<ListPtr>(storage_).get(); }
    const ListPtr &Value::as_list_ptr() const { return std::get<ListPtr>(storage_); }
    bool Value::is_text() const { return std::holds_alternative<std::string>(storage_); }
    const std::string &Value::as_text() const { return std::get<std::string>(storage_); }
    bool Value::is_function() const { return std::holds_alternative<FunctionPtr>(storage_); }
    bool Value::is_native() const { return std::holds_alternative<NativePtr>(storage_); }
    const FunctionPtr &Value::as_function() const { return std::get<FunctionPtr>(storage_); }
    const NativePtr &Value::as_native() const { return std::get<NativePtr>(storage_); }

    bool operator==(const Value &left, const Value &right)
    {
        if (left.is_list() && right.is_list())
        {
            const auto &left_items = left.as_list();
            const auto &right_items = right.as_list();
            if (left_items.size() != right_items.size())
                return false;
            for (std::size_t index = 0; index < left_items.size(); ++index)
            {
                if (!(left_items[index] == right_items[index]))
                    return false;
            }
            return true;
        }
        return left.storage() == right.storage();
    }

}