#include "luma/runtime/ops.hpp"

#include <cmath>
#include <iostream>
#include <stdexcept>
#include <utility>

namespace luma::rt
{
    namespace
    {
        [[noreturn]] void fail(const std::string &message)
        {
            throw std::runtime_error(message);
        }

        double number(const Value &value, const char *what)
        {
            if (!value.is_number())
                fail(std::string{what} + " needs a number, got " + value.type_name());
            return value.as_number();
        }
    }

    Value add(const Value &left, const Value &right)
    {
        if (left.is_number() && right.is_number())
            return Value{left.as_number() + right.as_number()};
        if (left.is_text() || right.is_text())
            return Value{left.display() + right.display()};
        fail("'+' needs two numbers or text, got " + left.type_name() + " and " + right.type_name());
    }

    Value subtract(const Value &left, const Value &right)
    {
        return Value{number(left, "'-' left side") - number(right, "'-' right side")};
    }

    Value multiply(const Value &left, const Value &right)
    {
        return Value{number(left, "'*' left side") * number(right, "'*' right side")};
    }

    Value divide(const Value &left, const Value &right)
    {
        const double denominator = number(right, "'/' right side");
        if (denominator == 0.0)
            fail("Cannot divide by zero");
        return Value{number(left, "'/' left side") / denominator};
    }

    Value modulo(const Value &left, const Value &right)
    {
        const double denominator = number(right, "'%' right side");
        if (denominator == 0.0)
            fail("Cannot take remainder of zero");
        return Value{std::fmod(number(left, "'%' left side"), denominator)};
    }

    Value equal(const Value &left, const Value &right) { return Value{left == right}; }
    Value not_equal(const Value &left, const Value &right) { return Value{!(left == right)}; }

    Value less(const Value &left, const Value &right)
    {
        return Value{number(left, "'<' left side") < number(right, "'<' right side")};
    }

    Value less_equal(const Value &left, const Value &right)
    {
        return Value{number(left, "'<=' left side") <= number(right, "'<=' right side")};
    }

    Value greater(const Value &left, const Value &right)
    {
        return Value{number(left, "'>' left side") > number(right, "'>' right side")};
    }

    Value greater_equal(const Value &left, const Value &right)
    {
        return Value{number(left, "'>=' left side") >= number(right, "'>=' right side")};
    }

    Value logical_and(const Value &left, const Value &right) { return Value{left.truthy() && right.truthy()}; }
    Value logical_or(const Value &left, const Value &right) { return Value{left.truthy() || right.truthy()}; }

    Value negate(const Value &value) { return Value{-number(value, "'-' (negate)")}; }
    Value logical_not(const Value &value) { return Value{!value.truthy()}; }

    Value index_get(const Value &base, const Value &index)
    {
        const double raw_index = number(index, "index");
        if (raw_index < 0 || std::floor(raw_index) != raw_index)
            fail("Index must be a whole, non-negative number");
        const auto position = static_cast<std::size_t>(raw_index);
        if (base.is_list())
        {
            const auto &items = base.as_list();
            if (position >= items.size())
                fail("List index out of range");
            return items[position];
        }
        if (base.is_text())
        {
            const auto &text = base.as_text();
            if (position >= text.size())
                fail("Text index out of range");
            return Value{std::string(1, text[position])};
        }
        fail("Cannot index a " + base.type_name());
    }

    void index_set(const Value &base, const Value &index, Value value)
    {
        const double raw_index = number(index, "index");
        if (raw_index < 0 || std::floor(raw_index) != raw_index)
            fail("Index must be a whole, non-negative number");
        const auto position = static_cast<std::size_t>(raw_index);
        if (!base.is_list())
            fail("Only list elements can be assigned to, not a " + base.type_name());
        auto &items = *base.as_list_ptr();
        if (position >= items.size())
            fail("List index out of range");
        items[position] = std::move(value);
    }

    Value make_list(std::vector<Value> items)
    {
        return Value{std::make_shared<std::vector<Value>>(std::move(items))};
    }

    bool counting_loop_continues(const Value &counter, const Value &stop, const Value &step)
    {
        const double current = number(counter, "counting loop counter");
        const double limit = number(stop, "counting loop stop");
        const double delta = number(step, "counting loop step");
        if (delta > 0)
            return current <= limit;
        if (delta < 0)
            return current >= limit;
        return false; // a step of 0 never runs instead of hanging forever
    }

    void show(const Value &value)
    {
        std::cout << value.display() << '\n';
    }

}
