#include "luma/lex/lexer.hpp"

#include <cctype>
#include <string>
#include <unordered_map>

#include "luma/core/diagnostic.hpp"

namespace luma
{
    namespace
    {

        const std::unordered_map<std::string, TokenKind> keywords{
            {"let", TokenKind::let_keyword},
            {"show", TokenKind::show_keyword},
            {"when", TokenKind::when_keyword},
            {"otherwise", TokenKind::otherwise_keyword},
            {"repeat", TokenKind::repeat_keyword},
            {"true", TokenKind::true_keyword},
            {"false", TokenKind::false_keyword},
            {"nothing", TokenKind::nothing_keyword},
            {"and", TokenKind::and_keyword},
            {"or", TokenKind::or_keyword},
            {"not", TokenKind::not_keyword},
            {"if", TokenKind::if_keyword},
            {"elif", TokenKind::elif_keyword},
            {"else", TokenKind::else_keyword},
            {"func", TokenKind::func_keyword},
            {"return", TokenKind::return_keyword},
            {"for", TokenKind::for_keyword},
            {"in", TokenKind::in_keyword},
            {"to", TokenKind::to_keyword},
            {"step", TokenKind::step_keyword},
            {"while", TokenKind::while_keyword},
            {"until", TokenKind::until_keyword},
            {"forever", TokenKind::forever_keyword},
            {"break", TokenKind::break_keyword},
            {"continue", TokenKind::continue_keyword},
            {"import", TokenKind::import_keyword},
            {"pass", TokenKind::pass_keyword},
        };

        bool is_identifier_start(char character)
        {
            return std::isalpha(static_cast<unsigned char>(character)) != 0 || character == '_';
        }

        bool is_identifier_part(char character)
        {
            return std::isalnum(static_cast<unsigned char>(character)) != 0 || character == '_';
        }

    }

    Lexer::Lexer(std::string_view source) : source_(source) {}

    std::vector<Token> Lexer::scan() const
    {
        std::vector<Token> tokens;
        std::vector<std::size_t> indentation{0};
        std::size_t start = 0;
        std::size_t line_number = 1;

        while (start <= source_.size())
        {
            const auto end = source_.find('\n', start);
            const auto length = end == std::string_view::npos ? source_.size() - start : end - start;
            auto line = source_.substr(start, length);
            if (!line.empty() && line.back() == '\r')
            {
                line.remove_suffix(1);
            }

            std::size_t indent = 0;
            while (indent < line.size() && line[indent] == ' ')
            {
                ++indent;
            }
            if (indent < line.size() && line[indent] == '\t')
            {
                fail("Use spaces for indentation, not tabs", {line_number, indent + 1});
            }
            const auto content = line.substr(indent);
            if (!content.empty() && content.front() != '#')
            {
                if (indent > indentation.back())
                {
                    indentation.push_back(indent);
                    tokens.push_back({TokenKind::indent, "", {line_number, 1}});
                }
                while (indent < indentation.back())
                {
                    indentation.pop_back();
                    tokens.push_back({TokenKind::dedent, "", {line_number, 1}});
                }
                if (indent != indentation.back())
                {
                    fail("Indentation does not match any outer block", {line_number, 1});
                }

                std::size_t current = indent;
                while (current < line.size())
                {
                    const char character = line[current];
                    const SourceLocation location{line_number, current + 1};
                    if (character == ' ' || character == '\r')
                    {
                        ++current;
                    }
                    else if (character == '#')
                    {
                        break;
                    }
                    else if (is_identifier_start(character))
                    {
                        const auto first = current++;
                        while (current < line.size() && is_identifier_part(line[current]))
                        {
                            ++current;
                        }
                        const std::string word{line.substr(first, current - first)};
                        const auto keyword = keywords.find(word);
                        tokens.push_back({keyword == keywords.end() ? TokenKind::identifier : keyword->second, word, location});
                    }
                    else if (std::isdigit(static_cast<unsigned char>(character)) != 0)
                    {
                        const auto first = current++;
                        bool decimal = false;
                        while (current < line.size() && (std::isdigit(static_cast<unsigned char>(line[current])) != 0 ||
                                                         (line[current] == '.' && !decimal)))
                        {
                            decimal = decimal || line[current] == '.';
                            ++current;
                        }
                        tokens.push_back({TokenKind::number, std::string{line.substr(first, current - first)}, location});
                    }
                    else if (character == '\"' || character == '\'')
                    {
                        const char quote = character;
                        ++current;
                        std::string text;
                        bool closed = false;
                        while (current < line.size())
                        {
                            const char value = line[current++];
                            if (value == quote)
                            {
                                closed = true;
                                break;
                            }
                            if (value == '\\' && current < line.size())
                            {
                                const char escaped = line[current++];
                                text += escaped == 'n' ? '\n' : escaped == 't' ? '\t'
                                                                               : escaped;
                            }
                            else
                            {
                                text += value;
                            }
                        }
                        if (!closed)
                        {
                            fail("Text value is missing its closing quote", location);
                        }
                        tokens.push_back({TokenKind::text, std::move(text), location});
                    }
                    else
                    {
                        const auto next_is_equal = current + 1 < line.size() && line[current + 1] == '=';
                        const auto next_is_star = current + 1 < line.size() && line[current + 1] == '*';
                        TokenKind kind{};
                        std::size_t width = 1;
                        switch (character)
                        {
                        case '(':
                            kind = TokenKind::left_paren;
                            break;
                        case ')':
                            kind = TokenKind::right_paren;
                            break;
                        case ':':
                            kind = TokenKind::colon;
                            break;
                        case ';':
                            kind = TokenKind::semicolon;
                            break;
                        case '+':
                            kind = next_is_equal ? TokenKind::plus_equal : TokenKind::plus;
                            width += next_is_equal;
                            break;
                        case '-':
                            kind = next_is_equal ? TokenKind::minus_equal : TokenKind::minus;
                            width += next_is_equal;
                            break;
                        case '*':
                            if (next_is_star)
                            {
                                kind = TokenKind::star_star;
                                ++width;
                            }
                            else
                            {
                                kind = next_is_equal ? TokenKind::star_equal : TokenKind::star;
                                width += next_is_equal;
                            }
                            break;
                        case '/':
                            kind = next_is_equal ? TokenKind::slash_equal : TokenKind::slash;
                            width += next_is_equal;
                            break;
                        case '%':
                            kind = next_is_equal ? TokenKind::percent_equal : TokenKind::percent;
                            width += next_is_equal;
                            break;
                        case ',':
                            kind = TokenKind::comma;
                            break;
                        case '[':
                            kind = TokenKind::left_bracket;
                            break;
                        case ']':
                            kind = TokenKind::right_bracket;
                            break;
                        case '=':
                            kind = next_is_equal ? TokenKind::equal_equal : TokenKind::equal;
                            width += next_is_equal;
                            break;
                        case '!':
                            if (!next_is_equal)
                                fail("Use != for not equal", location);
                            kind = TokenKind::bang_equal;
                            ++width;
                            break;
                        case '<':
                            kind = next_is_equal ? TokenKind::less_equal : TokenKind::less;
                            width += next_is_equal;
                            break;
                        case '>':
                            kind = next_is_equal ? TokenKind::greater_equal : TokenKind::greater;
                            width += next_is_equal;
                            break;
                        default:
                            fail(std::string{"I do not understand '"} + character + "'", location);
                        }
                        tokens.push_back({kind, std::string{line.substr(current, width)}, location});
                        current += width;
                    }
                }
                tokens.push_back({TokenKind::newline, "", {line_number, line.size() + 1}});
            }

            if (end == std::string_view::npos)
                break;
            start = end + 1;
            ++line_number;
        }

        while (indentation.size() > 1)
        {
            indentation.pop_back();
            tokens.push_back({TokenKind::dedent, "", {line_number, 1}});
        }
        tokens.push_back({TokenKind::end, "", {line_number, 1}});
        return tokens;
    }

}