#include <string_view>
#include <vector>

#include "luma/app/application.hpp"

int main(int argc, char *argv[])
{
    std::vector<std::string_view> arguments;
    arguments.reserve(static_cast<std::size_t>(argc));
    for (int index = 0; index < argc; ++index)
        arguments.emplace_back(argv[index]);
    return luma::Application{}.run(arguments);
}