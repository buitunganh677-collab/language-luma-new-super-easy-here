#include "luma/app/application.hpp"

#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <sstream>

#include "luma/app/cpp_backend.hpp"
#include "luma/build_config.hpp"
#include "luma/bytecode/compiler.hpp"
#include "luma/core/diagnostic.hpp"
#include "luma/core/source.hpp"
#include "luma/lex/lexer.hpp"
#include "luma/parse/parser.hpp"
#include "luma/runtime/vm.hpp"
#include "luma/version.hpp"

namespace luma
{
    namespace
    {

        void print_usage()
        {
            std::cout << "Luma " << version << " -- a small, readable, compiled-friendly language\n\n"
                       << "Usage:\n"
                       << "  luma <file.luma>            Run a program with the interpreter\n"
                       << "  luma run <file.luma>        Same as above, explicit form\n"
                       << "  luma build <file.luma> [-o output]\n"
                       << "                              Compile to a native executable (needs g++)\n"
                       << "  luma --version               Print the version\n"
                       << "  luma --help                  Show this message\n";
        }

        Program parse_source(const std::string &source)
        {
            const auto tokens = Lexer{source}.scan();
            return Parser{tokens}.parse();
        }

        // Python-like module loading: `import utils` (or `import "sub/utils.luma"`)
        // loads the file relative to the importing file and splices its
        // statements in place. Each file is loaded at most once per program,
        // which also makes circular imports harmless.
        void load_into(const std::filesystem::path &path, Program &merged,
                       std::vector<std::filesystem::path> &loaded)
        {
            namespace fs = std::filesystem;
            std::error_code ignored;
            fs::path canonical = fs::weakly_canonical(path, ignored);
            if (canonical.empty())
                canonical = fs::absolute(path);
            for (const auto &existing : loaded)
                if (existing == canonical)
                    return;
            loaded.push_back(canonical);

            const std::string source = read_source_file(path.string());
            Program program = parse_source(source);
            for (auto &statement : program.statements)
            {
                if (const auto *import_stmt = dynamic_cast<const ImportStmt *>(statement.get()))
                {
                    fs::path module_path{import_stmt->module};
                    if (!module_path.has_extension())
                        module_path += ".luma";
                    load_into(path.parent_path() / module_path, merged, loaded);
                    continue;
                }
                merged.statements.push_back(std::move(statement));
            }
        }

        Program load_program(const std::string &path)
        {
            Program merged;
            std::vector<std::filesystem::path> loaded;
            load_into(std::filesystem::path{path}, merged, loaded);
            return merged;
        }

        int run_file(const std::string &path)
        {
            try
            {
                const auto program = load_program(path);
                const auto chunk = Compiler{}.compile(program);
                VirtualMachine{}.run(chunk);
                return 0;
            }
            catch (const Diagnostic &error)
            {
                std::cerr << path << ": " << error.what() << '\n';
                return 1;
            }
            catch (const std::exception &error)
            {
                std::cerr << "Luma: " << error.what() << '\n';
                return 1;
            }
        }

        std::string quote(const std::string &value) { return "\"" + value + "\""; }

        // Paths needed to compile a generated program. Prefers the paths baked
        // in at CMake-configure time (developer checkout); falls back to
        // directories next to the installed luma.exe (e.g. {app}\bin\luma.exe
        // with {app}\include and {app}\src), then to plain `g++` on PATH.
        struct BuildPaths
        {
            std::string compiler;
            std::string include_dir;
            std::string source_dir;
        };

        BuildPaths resolve_build_paths(const std::filesystem::path &exe_dir)
        {
            namespace fs = std::filesystem;
            BuildPaths paths;

            std::error_code ignored;
            paths.compiler = fs::exists(config::cxx_compiler, ignored) ? config::cxx_compiler : "g++";

            const fs::path include_candidates[] = {fs::path{config::include_dir}, exe_dir / "include",
                                                   exe_dir / ".." / "include"};
            paths.include_dir = config::include_dir;
            for (const auto &candidate : include_candidates)
            {
                if (fs::exists(candidate / "luma" / "runtime" / "value.hpp", ignored))
                {
                    paths.include_dir = candidate.string();
                    break;
                }
            }

            const fs::path source_candidates[] = {fs::path{config::source_dir}, exe_dir, exe_dir / ".."};
            paths.source_dir = config::source_dir;
            for (const auto &candidate : source_candidates)
            {
                if (fs::exists(candidate / "src" / "runtime" / "value.cpp", ignored))
                {
                    paths.source_dir = candidate.string();
                    break;
                }
            }
            return paths;
        }

        int build_file(const std::string &source_path, std::string output_path, const std::filesystem::path &exe_dir)
        {
            std::string generated_cpp;
            try
            {
                const auto program = load_program(source_path);
                generated_cpp = codegen::generate_cpp(program);
            }
            catch (const Diagnostic &error)
            {
                std::cerr << source_path << ": " << error.what() << '\n';
                return 1;
            }
            catch (const std::exception &error)
            {
                std::cerr << source_path << ": " << error.what() << '\n';
                return 1;
            }

            const std::filesystem::path source_file{source_path};
            const std::filesystem::path generated_path = std::filesystem::path{source_path + ".generated.cpp"};
            {
                std::ofstream generated_stream(generated_path, std::ios::binary);
                generated_stream << generated_cpp;
            }

            if (output_path.empty())
            {
                std::filesystem::path candidate = source_file;
#ifdef _WIN32
                candidate.replace_extension(".exe");
#else
                candidate.replace_extension("");
#endif
                output_path = candidate.string();
            }

            std::ostringstream command;
            const BuildPaths paths = resolve_build_paths(exe_dir);
            command << quote(paths.compiler) << " -std=c++23 -O2"
                    << " -I" << quote(paths.include_dir);
            if (config::have_sdl2)
                command << " -DLUMA_HAVE_SDL2=1 " << config::sdl2_compile_flags;
            command << ' ' << quote(generated_path.string())
                    << ' ' << quote((std::filesystem::path{paths.source_dir} / "src/runtime/value.cpp").string())
                    << ' ' << quote((std::filesystem::path{paths.source_dir} / "src/runtime/ops.cpp").string())
                    << ' ' << quote((std::filesystem::path{paths.source_dir} / "src/stdlib/natives.cpp").string())
                    << ' ' << quote((std::filesystem::path{paths.source_dir} / "src/stdlib/window.cpp").string())
                    << " -o " << quote(output_path);
            if (config::have_sdl2)
                command << ' ' << config::sdl2_link_flags;

            std::cout << "Luma: compiling " << source_path << " -> " << output_path << '\n';
            const int status = std::system(command.str().c_str());
            if (status != 0)
            {
                std::cerr << "Luma: native build failed. Make sure g++ (MinGW-w64) is installed and on PATH.\n"
                              "Generated C++ kept at "
                           << generated_path.string() << " for inspection.\n";
                return 1;
            }
            std::cout << "Luma: built " << output_path << '\n';
            return 0;
        }

    }

    int Application::run(const std::vector<std::string_view> &arguments) const
    {
        if (arguments.size() < 2)
        {
            print_usage();
            return 1;
        }

        const std::string_view command = arguments[1];
        if (command == "--version" || command == "version")
        {
            std::cout << "Luma " << version << '\n';
            return 0;
        }
        if (command == "--help" || command == "help")
        {
            print_usage();
            return 0;
        }
        if (command == "run")
        {
            if (arguments.size() < 3)
            {
                std::cerr << "Usage: luma run <file.luma>\n";
                return 1;
            }
            return run_file(std::string{arguments[2]});
        }
        if (command == "build")
        {
            if (arguments.size() < 3)
            {
                std::cerr << "Usage: luma build <file.luma> [-o output]\n";
                return 1;
            }
            std::string output_path;
            for (std::size_t index = 3; index < arguments.size(); ++index)
            {
                if (arguments[index] == "-o" && index + 1 < arguments.size())
                    output_path = arguments[++index];
            }
            std::filesystem::path exe_dir;
            try
            {
                exe_dir = std::filesystem::absolute(std::filesystem::path{std::string{arguments[0]}}).parent_path();
            }
            catch (const std::exception &)
            {
                exe_dir = std::filesystem::current_path();
            }
            return build_file(std::string{arguments[2]}, output_path, exe_dir);
        }

        // Back-compatible shorthand: `luma file.luma` behaves like `luma run file.luma`.
        return run_file(std::string{command});
    }

}
