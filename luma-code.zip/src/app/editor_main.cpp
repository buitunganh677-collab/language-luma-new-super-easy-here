// Luma Editor -- a small Windows code editor dedicated to the Luma language.
//
// Features:
//   * Syntax highlighting for Luma (keywords, strings, numbers, comments)
//   * Run (F5) and Build to EXE (F6) straight from the editor -- opens a
//     console window using the luma.exe found next to this program (or on PATH)
//   * Tab inserts 4 spaces (Luma indentation), Enter auto-indents and adds
//     one extra level after a line ending in ':'
//   * UTF-8 files, open/save dialogs, unsaved-changes protection
//
// Built as the separate `luma-edit.exe` target (see CMakeLists.txt) and
// shipped by install.iss together with the compiler.

#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif

#include <windows.h>

#include <commctrl.h>
#include <commdlg.h>
#include <richedit.h>
#include <shellapi.h>

#include <algorithm>
#include <cwctype>
#include <filesystem>
#include <fstream>
#include <sstream>
#include <string>
#include <unordered_set>
#include <vector>

#ifndef MSFTEDIT_CLASS
#define MSFTEDIT_CLASS L"RICHEDIT50W"
#endif
#ifndef EM_GETSCROLLPOS
#define EM_GETSCROLLPOS (WM_USER + 221)
#endif
#ifndef EM_SETSCROLLPOS
#define EM_SETSCROLLPOS (WM_USER + 222)
#endif

namespace
{

    constexpr wchar_t kWindowClass[] = L"LumaEditorWindow";
    constexpr wchar_t kAppTitle[] = L"Luma Editor";
    constexpr int kEditorId = 100;
    constexpr int kStatusId = 101;

    enum MenuCommand
    {
        ID_FILE_NEW = 200,
        ID_FILE_OPEN,
        ID_FILE_SAVE,
        ID_FILE_SAVEAS,
        ID_FILE_EXIT,
        ID_RUN_RUN,
        ID_RUN_BUILD,
        ID_HELP_ABOUT,
    };

    HWND g_main_window = nullptr;
    HWND g_editor = nullptr;
    HWND g_status = nullptr;
    std::wstring g_file_path;
    bool g_dirty = false;
    bool g_highlighting = false;

    const COLORREF kColorDefault = RGB(30, 30, 30);
    const COLORREF kColorKeyword = RGB(0, 0, 200);
    const COLORREF kColorString = RGB(163, 21, 21);
    const COLORREF kColorNumber = RGB(125, 0, 190);
    const COLORREF kColorComment = RGB(0, 128, 0);

    const std::unordered_set<std::wstring> &keywords()
    {
        static const std::unordered_set<std::wstring> table{
            L"let", L"show", L"when", L"otherwise", L"repeat", L"true", L"false", L"nothing",
            L"and", L"or", L"not", L"if", L"elif", L"else", L"func", L"return", L"for",
            L"in", L"to", L"step", L"while", L"until", L"forever", L"break", L"continue",
            L"import", L"pass",
        };
        return table;
    }

    std::wstring widen(const std::string &text)
    {
        if (text.empty())
            return {};
        const int length = MultiByteToWideChar(CP_UTF8, 0, text.data(), static_cast<int>(text.size()), nullptr, 0);
        std::wstring result(static_cast<std::size_t>(length), L'\0');
        MultiByteToWideChar(CP_UTF8, 0, text.data(), static_cast<int>(text.size()), result.data(), length);
        return result;
    }

    std::string narrow(const std::wstring &text)
    {
        if (text.empty())
            return {};
        const int length =
            WideCharToMultiByte(CP_UTF8, 0, text.data(), static_cast<int>(text.size()), nullptr, 0, nullptr, nullptr);
        std::string result(static_cast<std::size_t>(length), '\0');
        WideCharToMultiByte(CP_UTF8, 0, text.data(), static_cast<int>(text.size()), result.data(), length, nullptr,
                            nullptr);
        return result;
    }

    std::wstring window_text()
    {
        const int length = GetWindowTextLengthW(g_editor);
        std::wstring text(static_cast<std::size_t>(length) + 1, L'\0');
        const int copied = GetWindowTextW(g_editor, text.data(), length + 1);
        text.resize(static_cast<std::size_t>(copied));
        return text;
    }

    void update_status_bar()
    {
        if (g_status == nullptr || g_editor == nullptr)
            return;

        CHARRANGE selection{};
        SendMessageW(g_editor, EM_EXGETSEL, 0, reinterpret_cast<LPARAM>(&selection));
        const LONG line = static_cast<LONG>(SendMessageW(g_editor, EM_EXLINEFROMCHAR, 0, selection.cpMin));
        const LONG line_start = static_cast<LONG>(SendMessageW(g_editor, EM_LINEINDEX, line, 0));
        const LONG column = selection.cpMin - line_start;

        const std::wstring file_name = g_file_path.empty()
                                           ? std::wstring{L"untitled.luma"}
                                           : std::filesystem::path{g_file_path}.filename().wstring();
        std::wstring status = file_name + (g_dirty ? L"  |  Modified" : L"  |  Saved") + L"  |  Line " +
                              std::to_wstring(line + 1) + L", Column " + std::to_wstring(column + 1);
        SetWindowTextW(g_status, status.c_str());
    }

    void set_title()
    {
        std::wstring name = g_file_path.empty()
                                ? std::wstring{L"untitled.luma"}
                                : std::filesystem::path{g_file_path}.filename().wstring();
        std::wstring title = name + (g_dirty ? L" *" : L"") + L" - " + kAppTitle;
        SetWindowTextW(g_main_window, title.c_str());
        update_status_bar();
    }

    void apply_color(LONG start, LONG stop, COLORREF color)
    {
        CHARRANGE range{start, stop};
        SendMessageW(g_editor, EM_EXSETSEL, 0, reinterpret_cast<LPARAM>(&range));
        CHARFORMAT2W format{};
        format.cbSize = sizeof(format);
        format.dwMask = CFM_COLOR;
        format.crTextColor = color;
        SendMessageW(g_editor, EM_SETCHARFORMAT, SCF_SELECTION, reinterpret_cast<LPARAM>(&format));
    }

    // Recolors the whole document. Positions are computed on a copy of the
    // text with '\n' removed, because the rich edit control counts a line
    // break as a single character internally.
    void highlight()
    {
        if (g_highlighting || g_editor == nullptr)
            return;
        g_highlighting = true;

        const LRESULT old_mask = SendMessageW(g_editor, EM_SETEVENTMASK, 0, 0);
        SendMessageW(g_editor, WM_SETREDRAW, FALSE, 0);
        CHARRANGE saved_selection{};
        SendMessageW(g_editor, EM_EXGETSEL, 0, reinterpret_cast<LPARAM>(&saved_selection));
        POINT saved_scroll{};
        SendMessageW(g_editor, EM_GETSCROLLPOS, 0, reinterpret_cast<LPARAM>(&saved_scroll));

        std::wstring text = window_text();
        text.erase(std::remove(text.begin(), text.end(), L'\n'), text.end());

        apply_color(0, static_cast<LONG>(text.size()), kColorDefault);

        std::size_t index = 0;
        while (index < text.size())
        {
            const wchar_t character = text[index];
            if (character == L'#')
            {
                std::size_t stop = index;
                while (stop < text.size() && text[stop] != L'\r')
                    ++stop;
                apply_color(static_cast<LONG>(index), static_cast<LONG>(stop), kColorComment);
                index = stop;
            }
            else if (character == L'"' || character == L'\'')
            {
                const wchar_t quote = character;
                std::size_t stop = index + 1;
                while (stop < text.size() && text[stop] != quote && text[stop] != L'\r')
                {
                    if (text[stop] == L'\\')
                        ++stop;
                    ++stop;
                }
                if (stop < text.size() && text[stop] == quote)
                    ++stop;
                apply_color(static_cast<LONG>(index), static_cast<LONG>(stop), kColorString);
                index = stop;
            }
            else if (iswdigit(character) != 0)
            {
                std::size_t stop = index;
                while (stop < text.size() && (iswdigit(text[stop]) != 0 || text[stop] == L'.'))
                    ++stop;
                apply_color(static_cast<LONG>(index), static_cast<LONG>(stop), kColorNumber);
                index = stop;
            }
            else if (iswalpha(character) != 0 || character == L'_')
            {
                std::size_t stop = index;
                while (stop < text.size() && (iswalnum(text[stop]) != 0 || text[stop] == L'_'))
                    ++stop;
                const std::wstring word = text.substr(index, stop - index);
                if (keywords().count(word) != 0)
                    apply_color(static_cast<LONG>(index), static_cast<LONG>(stop), kColorKeyword);
                index = stop;
            }
            else
            {
                ++index;
            }
        }

        SendMessageW(g_editor, EM_EXSETSEL, 0, reinterpret_cast<LPARAM>(&saved_selection));
        SendMessageW(g_editor, EM_SETSCROLLPOS, 0, reinterpret_cast<LPARAM>(&saved_scroll));
        SendMessageW(g_editor, WM_SETREDRAW, TRUE, 0);
        InvalidateRect(g_editor, nullptr, TRUE);
        SendMessageW(g_editor, EM_SETEVENTMASK, 0, old_mask);
        g_highlighting = false;
    }

    bool save_to(const std::wstring &path)
    {
        const std::string utf8 = narrow(window_text());
        std::ofstream stream{std::filesystem::path{path}, std::ios::binary};
        if (!stream)
        {
            MessageBoxW(g_main_window, (L"Could not save to:\n" + path).c_str(), kAppTitle,
                        MB_OK | MB_ICONERROR);
            return false;
        }
        stream << utf8;
        stream.close();
        g_file_path = path;
        g_dirty = false;
        set_title();
        return true;
    }

    bool save_as()
    {
        wchar_t buffer[MAX_PATH] = L"";
        if (!g_file_path.empty() && g_file_path.size() < MAX_PATH - 1)
            std::copy(g_file_path.begin(), g_file_path.end(), buffer);
        OPENFILENAMEW dialog{};
        dialog.lStructSize = sizeof(dialog);
        dialog.hwndOwner = g_main_window;
        dialog.lpstrFilter = L"Luma programs (*.luma)\0*.luma\0All files (*.*)\0*.*\0";
        dialog.lpstrFile = buffer;
        dialog.nMaxFile = MAX_PATH;
        dialog.lpstrDefExt = L"luma";
        dialog.Flags = OFN_OVERWRITEPROMPT | OFN_PATHMUSTEXIST;
        if (GetSaveFileNameW(&dialog) == FALSE)
            return false;
        return save_to(buffer);
    }

    bool save()
    {
        if (g_file_path.empty())
            return save_as();
        return save_to(g_file_path);
    }

    // Returns true when it is OK to discard the current buffer.
    bool confirm_unsaved()
    {
        if (!g_dirty)
            return true;
        const int answer = MessageBoxW(g_main_window, L"Save the changes to this file first?", kAppTitle,
                                       MB_YESNOCANCEL | MB_ICONQUESTION);
        if (answer == IDCANCEL)
            return false;
        if (answer == IDYES)
            return save();
        return true;
    }

    void load_file(const std::wstring &path)
    {
        std::ifstream stream{std::filesystem::path{path}, std::ios::binary};
        if (!stream)
        {
            MessageBoxW(g_main_window, (L"Could not open:\n" + path).c_str(), kAppTitle, MB_OK | MB_ICONERROR);
            return;
        }
        std::ostringstream contents;
        contents << stream.rdbuf();
        SetWindowTextW(g_editor, widen(contents.str()).c_str());
        g_file_path = path;
        g_dirty = false;
        set_title();
        highlight();
    }

    void open_file_dialog()
    {
        if (!confirm_unsaved())
            return;
        wchar_t buffer[MAX_PATH] = L"";
        OPENFILENAMEW dialog{};
        dialog.lStructSize = sizeof(dialog);
        dialog.hwndOwner = g_main_window;
        dialog.lpstrFilter = L"Luma programs (*.luma)\0*.luma\0All files (*.*)\0*.*\0";
        dialog.lpstrFile = buffer;
        dialog.nMaxFile = MAX_PATH;
        dialog.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST;
        if (GetOpenFileNameW(&dialog) == FALSE)
            return;
        load_file(buffer);
    }

    void new_file()
    {
        if (!confirm_unsaved())
            return;
        SetWindowTextW(g_editor, L"");
        g_file_path.clear();
        g_dirty = false;
        set_title();
    }

    std::wstring find_luma()
    {
        wchar_t module_path[MAX_PATH] = L"";
        GetModuleFileNameW(nullptr, module_path, MAX_PATH);
        const std::filesystem::path directory = std::filesystem::path{module_path}.parent_path();
        std::error_code ignored;
        const std::filesystem::path candidate = directory / L"luma.exe";
        if (std::filesystem::exists(candidate, ignored))
            return candidate.wstring();
        return L"luma";
    }

    void run_program(bool build)
    {
        // The program on disk is what runs, so make sure it is saved first.
        if (g_file_path.empty() || g_dirty)
        {
            if (!save())
                return;
        }
        const std::wstring luma = find_luma();
        const std::wstring verb = build ? L"build" : L"run";
        std::wstring command =
            L"cmd.exe /k \"\"" + luma + L"\" " + verb + L" \"" + g_file_path + L"\"\"";
        const std::wstring working_directory = std::filesystem::path{g_file_path}.parent_path().wstring();

        STARTUPINFOW startup{};
        startup.cb = sizeof(startup);
        PROCESS_INFORMATION process{};
        std::vector<wchar_t> mutable_command(command.begin(), command.end());
        mutable_command.push_back(L'\0');
        if (CreateProcessW(nullptr, mutable_command.data(), nullptr, nullptr, FALSE, CREATE_NEW_CONSOLE, nullptr,
                           working_directory.empty() ? nullptr : working_directory.c_str(), &startup, &process))
        {
            CloseHandle(process.hProcess);
            CloseHandle(process.hThread);
        }
        else
        {
            MessageBoxW(g_main_window,
                        L"Could not start luma.exe.\nInstall Luma or put luma.exe next to this editor.", kAppTitle,
                        MB_OK | MB_ICONERROR);
        }
    }

    // Tab -> 4 spaces; Enter -> keep the current indentation and add one
    // level after a line that ends with ':'.
    LRESULT CALLBACK editor_subclass(HWND window, UINT message, WPARAM w_param, LPARAM l_param, UINT_PTR, DWORD_PTR)
    {
        if (message == WM_CHAR && w_param == L'\t')
        {
            SendMessageW(window, EM_REPLACESEL, TRUE, reinterpret_cast<LPARAM>(L"    "));
            return 0;
        }
        if (message == WM_CHAR && w_param == L'\r')
        {
            CHARRANGE selection{};
            SendMessageW(window, EM_EXGETSEL, 0, reinterpret_cast<LPARAM>(&selection));
            const LONG line = static_cast<LONG>(SendMessageW(window, EM_EXLINEFROMCHAR, 0, selection.cpMin));
            const LONG line_start = static_cast<LONG>(SendMessageW(window, EM_LINEINDEX, line, 0));

            wchar_t buffer[1024];
            reinterpret_cast<WORD *>(buffer)[0] = 1022;
            const LONG copied = static_cast<LONG>(SendMessageW(window, EM_GETLINE, line, reinterpret_cast<LPARAM>(buffer)));
            std::wstring line_text(buffer, buffer + copied);

            const LONG caret_column = selection.cpMin - line_start;
            if (caret_column >= 0 && caret_column < static_cast<LONG>(line_text.size()))
                line_text.resize(static_cast<std::size_t>(caret_column));

            std::wstring indent;
            for (const wchar_t ch : line_text)
            {
                if (ch != L' ')
                    break;
                indent += L' ';
            }
            std::wstring trimmed = line_text;
            while (!trimmed.empty() && iswspace(trimmed.back()) != 0)
                trimmed.pop_back();
            if (!trimmed.empty() && trimmed.back() == L':')
                indent += L"    ";

            const std::wstring replacement = L"\r\n" + indent;
            SendMessageW(window, EM_REPLACESEL, TRUE, reinterpret_cast<LPARAM>(replacement.c_str()));
            return 0;
        }
        return DefSubclassProc(window, message, w_param, l_param);
    }

    void create_editor_control(HWND parent)
    {
        LoadLibraryW(L"Msftedit.dll");
        g_editor = CreateWindowExW(0, MSFTEDIT_CLASS, L"",
                                   WS_CHILD | WS_VISIBLE | WS_VSCROLL | WS_HSCROLL | ES_MULTILINE |
                                       ES_AUTOVSCROLL | ES_AUTOHSCROLL | ES_NOHIDESEL | ES_WANTRETURN,
                                   0, 0, 100, 100, parent, reinterpret_cast<HMENU>(static_cast<UINT_PTR>(kEditorId)),
                                   GetModuleHandleW(nullptr), nullptr);

        CHARFORMAT2W format{};
        format.cbSize = sizeof(format);
        format.dwMask = CFM_FACE | CFM_SIZE | CFM_COLOR;
        {
            const wchar_t face[] = L"Consolas";
            std::copy(std::begin(face), std::end(face), format.szFaceName);
        }
        format.yHeight = 220; // 11pt in twips
        format.crTextColor = kColorDefault;
        SendMessageW(g_editor, EM_SETCHARFORMAT, SCF_ALL, reinterpret_cast<LPARAM>(&format));

        SendMessageW(g_editor, EM_SETEVENTMASK, 0, ENM_CHANGE | ENM_SELCHANGE);
        SetWindowSubclass(g_editor, editor_subclass, 1, 0);
    }

    void create_status_bar(HWND parent)
    {
        g_status = CreateWindowExW(0, STATUSCLASSNAMEW, L"", WS_CHILD | WS_VISIBLE | SBARS_SIZEGRIP,
                                  0, 0, 0, 0, parent, reinterpret_cast<HMENU>(static_cast<UINT_PTR>(kStatusId)),
                                  GetModuleHandleW(nullptr), nullptr);
        update_status_bar();
    }

    void layout_children(LPARAM size_param)
    {
        const int width = LOWORD(size_param);
        const int height = HIWORD(size_param);
        int status_height = 0;

        if (g_status != nullptr)
        {
            SendMessageW(g_status, WM_SIZE, 0, 0);
            RECT status_rect{};
            GetWindowRect(g_status, &status_rect);
            status_height = status_rect.bottom - status_rect.top;
        }

        if (g_editor != nullptr)
            MoveWindow(g_editor, 0, 0, width, std::max(0, height - status_height), TRUE);
    }

    HMENU build_menu()
    {
        HMENU bar = CreateMenu();
        HMENU file_menu = CreatePopupMenu();
        AppendMenuW(file_menu, MF_STRING, ID_FILE_NEW, L"&New\tCtrl+N");
        AppendMenuW(file_menu, MF_STRING, ID_FILE_OPEN, L"&Open...\tCtrl+O");
        AppendMenuW(file_menu, MF_STRING, ID_FILE_SAVE, L"&Save\tCtrl+S");
        AppendMenuW(file_menu, MF_STRING, ID_FILE_SAVEAS, L"Save &As...");
        AppendMenuW(file_menu, MF_SEPARATOR, 0, nullptr);
        AppendMenuW(file_menu, MF_STRING, ID_FILE_EXIT, L"E&xit");
        AppendMenuW(bar, MF_POPUP, reinterpret_cast<UINT_PTR>(file_menu), L"&File");

        HMENU run_menu = CreatePopupMenu();
        AppendMenuW(run_menu, MF_STRING, ID_RUN_RUN, L"&Run program\tF5");
        AppendMenuW(run_menu, MF_STRING, ID_RUN_BUILD, L"&Build to EXE\tF6");
        AppendMenuW(bar, MF_POPUP, reinterpret_cast<UINT_PTR>(run_menu), L"&Run");

        HMENU help_menu = CreatePopupMenu();
        AppendMenuW(help_menu, MF_STRING, ID_HELP_ABOUT, L"&About Luma Editor");
        AppendMenuW(bar, MF_POPUP, reinterpret_cast<UINT_PTR>(help_menu), L"&Help");
        return bar;
    }

    LRESULT CALLBACK window_procedure(HWND window, UINT message, WPARAM w_param, LPARAM l_param)
    {
        switch (message)
        {
        case WM_CREATE:
            g_main_window = window;
            create_editor_control(window);
            create_status_bar(window);
            return 0;
        case WM_SIZE:
            layout_children(l_param);
            return 0;
        case WM_SETFOCUS:
            SetFocus(g_editor);
            return 0;
        case WM_COMMAND:
            if (HIWORD(w_param) == EN_CHANGE && LOWORD(w_param) == kEditorId)
            {
                if (!g_highlighting)
                {
                    if (!g_dirty)
                    {
                        g_dirty = true;
                        set_title();
                    }
                    highlight();
                }
                return 0;
            }
            switch (LOWORD(w_param))
            {
            case ID_FILE_NEW:
                new_file();
                return 0;
            case ID_FILE_OPEN:
                open_file_dialog();
                return 0;
            case ID_FILE_SAVE:
                save();
                return 0;
            case ID_FILE_SAVEAS:
                save_as();
                return 0;
            case ID_FILE_EXIT:
                PostMessageW(window, WM_CLOSE, 0, 0);
                return 0;
            case ID_RUN_RUN:
                run_program(false);
                return 0;
            case ID_RUN_BUILD:
                run_program(true);
                return 0;
            case ID_HELP_ABOUT:
                MessageBoxW(window,
                            L"Luma Editor\n\nA tiny editor made only for the Luma language.\n"
                            L"F5 runs your program, F6 compiles it to a real .exe.\n"
                            L"Tab inserts 4 spaces and Enter keeps your indentation.",
                            kAppTitle, MB_OK | MB_ICONINFORMATION);
                return 0;
            default:
                break;
            }
            break;
        case WM_NOTIFY:
            if (const auto *header = reinterpret_cast<NMHDR *>(l_param);
                header != nullptr && header->hwndFrom == g_editor && header->code == EN_SELCHANGE)
            {
                update_status_bar();
                return 0;
            }
            break;
        case WM_CLOSE:
            if (confirm_unsaved())
                DestroyWindow(window);
            return 0;
        case WM_DESTROY:
            PostQuitMessage(0);
            return 0;
        default:
            break;
        }
        return DefWindowProcW(window, message, w_param, l_param);
    }

}

int WINAPI WinMain(HINSTANCE instance, HINSTANCE, LPSTR, int show_command)
{
    SetProcessDPIAware();
    INITCOMMONCONTROLSEX controls{sizeof(INITCOMMONCONTROLSEX), ICC_STANDARD_CLASSES | ICC_BAR_CLASSES};
    InitCommonControlsEx(&controls);

    WNDCLASSW window_class{};
    window_class.lpfnWndProc = window_procedure;
    window_class.hInstance = instance;
    window_class.lpszClassName = kWindowClass;
    window_class.hCursor = LoadCursorW(nullptr, IDC_ARROW);
    window_class.hbrBackground = reinterpret_cast<HBRUSH>(COLOR_WINDOW + 1);
    window_class.hIcon = LoadIconW(nullptr, IDI_APPLICATION);
    RegisterClassW(&window_class);

    HWND window = CreateWindowExW(0, kWindowClass, kAppTitle, WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT,
                                  1000, 700, nullptr, build_menu(), instance, nullptr);
    ShowWindow(window, show_command);
    set_title();

    // Open a file passed on the command line (e.g. double-clicked .luma file).
    int argument_count = 0;
    LPWSTR *arguments = CommandLineToArgvW(GetCommandLineW(), &argument_count);
    if (arguments != nullptr)
    {
        if (argument_count > 1)
            load_file(arguments[1]);
        LocalFree(arguments);
    }

    const ACCEL accelerators[] = {
        {FCONTROL | FVIRTKEY, 'N', ID_FILE_NEW},
        {FCONTROL | FVIRTKEY, 'O', ID_FILE_OPEN},
        {FCONTROL | FVIRTKEY, 'S', ID_FILE_SAVE},
        {FVIRTKEY, VK_F5, ID_RUN_RUN},
        {FVIRTKEY, VK_F6, ID_RUN_BUILD},
    };
    HACCEL accelerator_table = CreateAcceleratorTableW(const_cast<ACCEL *>(accelerators),
                                                       static_cast<int>(sizeof(accelerators) / sizeof(accelerators[0])));

    MSG message{};
    while (GetMessageW(&message, nullptr, 0, 0) > 0)
    {
        if (TranslateAcceleratorW(window, accelerator_table, &message) != 0)
            continue;
        TranslateMessage(&message);
        DispatchMessageW(&message);
    }
    DestroyAcceleratorTable(accelerator_table);
    return static_cast<int>(message.wParam);
}
