#include "luma/parse/parser.hpp"
#include <utility>
#include "luma/core/diagnostic.hpp"
namespace luma {
Parser::Parser(std::vector<Token> t) : tokens_(std::move(t)) {}
Program Parser::parse() {
    Program p; skip_newlines();
    while (!check(TokenKind::end)) { p.statements.push_back(statement()); skip_newlines(); }
    return p;
}
StmtPtr Parser::statement() {
    if (check(TokenKind::let_keyword)) return let_statement();
    if (check(TokenKind::identifier) && current_ + 1 < tokens_.size()) {
        const TokenKind next = tokens_[current_ + 1].kind;
        if (next == TokenKind::equal) {
            Token n = advance(); advance();
            return assignment_statement(std::move(n));
        }
        // Compound assignment (x += 1, ...) desugars to x = x <op> value.
        if (next == TokenKind::plus_equal || next == TokenKind::minus_equal || next == TokenKind::star_equal ||
            next == TokenKind::slash_equal || next == TokenKind::percent_equal) {
            Token n = advance();
            Token op = advance();
            TokenKind base = TokenKind::plus;
            switch (op.kind) {
            case TokenKind::plus_equal: base = TokenKind::plus; break;
            case TokenKind::minus_equal: base = TokenKind::minus; break;
            case TokenKind::star_equal: base = TokenKind::star; break;
            case TokenKind::slash_equal: base = TokenKind::slash; break;
            default: base = TokenKind::percent; break;
            }
            ExprPtr value = expression();
            expect_newline("assignment");
            ExprPtr current_value = std::make_unique<NameExpr>(n.location, n.lexeme);
            ExprPtr combined = std::make_unique<BinaryExpr>(op.location, std::move(current_value), base, std::move(value));
            return std::make_unique<AssignStmt>(n.location, std::move(n.lexeme), std::move(combined));
        }
    }
    if (check(TokenKind::show_keyword)) return show_statement();
    if (check(TokenKind::when_keyword) || check(TokenKind::if_keyword)) return when_statement();
    if (check(TokenKind::repeat_keyword)) return repeat_statement();
    if (check(TokenKind::func_keyword)) return func_statement();
    if (check(TokenKind::return_keyword)) return return_statement();
    if (check(TokenKind::for_keyword)) return for_statement();
    if (check(TokenKind::while_keyword)) return while_statement();
    if (check(TokenKind::until_keyword)) return until_statement();
    if (check(TokenKind::forever_keyword)) return forever_statement();
    if (check(TokenKind::break_keyword)) {
        Token k = advance();
        expect_newline("break");
        return std::make_unique<BreakStmt>(k.location);
    }
    if (check(TokenKind::continue_keyword)) {
        Token k = advance();
        expect_newline("continue");
        return std::make_unique<ContinueStmt>(k.location);
    }
    if (check(TokenKind::pass_keyword)) {
        Token k = advance();
        expect_newline("pass");
        return std::make_unique<PassStmt>(k.location);
    }
    if (check(TokenKind::import_keyword)) return import_statement();
    if (check(TokenKind::otherwise_keyword) || check(TokenKind::else_keyword) || check(TokenKind::elif_keyword))
        fail("Unexpected block keyword here", peek().location);
    return expression_statement();
}

StmtPtr Parser::let_statement() {
    Token k = advance();
    const Token& n = consume(TokenKind::identifier, "Need name after let");
    consume(TokenKind::equal, "Need = after name");
    ExprPtr v = expression(); expect_newline("let");
    return std::make_unique<LetStmt>(k.location, n.lexeme, std::move(v));
}
StmtPtr Parser::assignment_statement(Token n) {
    ExprPtr v = expression(); expect_newline("assignment");
    return std::make_unique<AssignStmt>(n.location, std::move(n.lexeme), std::move(v));
}
StmtPtr Parser::show_statement() {
    Token k = advance(); ExprPtr v = expression(); expect_newline("show");
    return std::make_unique<ShowStmt>(k.location, std::move(v));
}
StmtPtr Parser::repeat_statement() {
    Token k = advance(); ExprPtr c = expression();
    consume(TokenKind::colon, "Need : after count");
    return std::make_unique<RepeatStmt>(k.location, std::move(c), suite("repeat header"));
}
StmtPtr Parser::func_statement() {
    Token k = advance();
    const Token& n = consume(TokenKind::identifier, "Need name after func");
    consume(TokenKind::left_paren, "Need ( after name");
    std::vector<std::string> ps;
    if (!check(TokenKind::right_paren)) {
        do { ps.push_back(consume(TokenKind::identifier, "Need param").lexeme); } while (match(TokenKind::comma));
    }
    consume(TokenKind::right_paren, "Need ) after params");
    consume(TokenKind::colon, "Need : before body");
    return std::make_unique<FuncStmt>(k.location, n.lexeme, std::move(ps), suite("func header"));
}
StmtPtr Parser::return_statement() {
    Token k = advance();
    if (check(TokenKind::newline) || check(TokenKind::dedent) || check(TokenKind::end) ||
        check(TokenKind::semicolon)) {
        expect_newline("return");
        return std::make_unique<ReturnStmt>(k.location, ExprPtr{nullptr});
    }
    ExprPtr v = expression(); expect_newline("return");
    return std::make_unique<ReturnStmt>(k.location, std::move(v));
}
StmtPtr Parser::for_statement() {
    Token k = advance();
    const Token& n = consume(TokenKind::identifier, "Need name after for");
    consume(TokenKind::in_keyword, "Need in after name");
    ExprPtr it = expression();
    // `for i in 1 to 10 [step 2]:` -- an inclusive counting loop compiled as
    // a plain counter/compare/add loop (while-style, no list is built).
    if (match(TokenKind::to_keyword)) {
        ExprPtr stop = expression();
        ExprPtr step;
        if (match(TokenKind::step_keyword))
            step = expression();
        else
            step = std::make_unique<LiteralExpr>(k.location, Value{1.0});
        consume(TokenKind::colon, "Need : after target");
        return std::make_unique<CountForStmt>(k.location, n.lexeme, std::move(it), std::move(stop), std::move(step),
                                              suite("for header"));
    }
    consume(TokenKind::colon, "Need : after target");
    return std::make_unique<ForStmt>(k.location, n.lexeme, std::move(it), suite("for header"));
}
StmtPtr Parser::while_statement() {
    Token k = advance(); ExprPtr c = expression();
    consume(TokenKind::colon, "Need : after condition");
    return std::make_unique<WhileStmt>(k.location, std::move(c), suite("while header"));
}
// `until cond:` loops as long as cond is FALSE -- sugar for `while not cond:`.
StmtPtr Parser::until_statement() {
    Token k = advance(); ExprPtr c = expression();
    consume(TokenKind::colon, "Need : after condition");
    ExprPtr negated = std::make_unique<UnaryExpr>(k.location, TokenKind::not_keyword, std::move(c));
    return std::make_unique<WhileStmt>(k.location, std::move(negated), suite("until header"));
}
// `forever:` loops until a `break` -- sugar for `while true:`.
StmtPtr Parser::forever_statement() {
    Token k = advance();
    consume(TokenKind::colon, "Need : after forever");
    ExprPtr always = std::make_unique<LiteralExpr>(k.location, Value{true});
    return std::make_unique<WhileStmt>(k.location, std::move(always), suite("forever header"));
}
StmtPtr Parser::import_statement() {
    Token k = advance();
    std::string module;
    if (check(TokenKind::text))
        module = advance().lexeme;
    else
        module = consume(TokenKind::identifier, "Need a module name or \"file.luma\" after import").lexeme;
    expect_newline("import");
    return std::make_unique<ImportStmt>(k.location, std::move(module));
}

// Accepts both `when ... otherwise:` and Python-style `if ... elif ... else:`.
// An `elif` chain is desugared into nested WhenStmt otherwise-branches so the
// rest of the compiler only ever has to deal with a single construct.
StmtPtr Parser::when_statement() {
    Token k = advance();
    ExprPtr condition = expression();
    consume(TokenKind::colon, "Need : after condition");
    StmtList then_branch = suite("when/if header");

    StmtList otherwise_branch;
    if (check(TokenKind::elif_keyword)) {
        otherwise_branch.push_back(when_statement());
    } else if (match(TokenKind::otherwise_keyword) || match(TokenKind::else_keyword)) {
        consume(TokenKind::colon, "Need : after otherwise/else");
        otherwise_branch = suite("otherwise/else header");
    }
    return std::make_unique<WhenStmt>(k.location, std::move(condition), std::move(then_branch),
                                       std::move(otherwise_branch));
}

StmtPtr Parser::expression_statement() {
    ExprPtr value = expression();
    // `list[index] = value` -- an index expression followed by `=`.
    if (match(TokenKind::equal)) {
        auto *target = dynamic_cast<IndexExpr *>(value.get());
        if (target == nullptr)
            fail("Only names and list elements can be assigned to", value->location);
        ExprPtr next_value = expression();
        expect_newline("assignment");
        return std::make_unique<IndexAssignStmt>(value->location, std::move(target->base), std::move(target->index),
                                                 std::move(next_value));
    }
    expect_newline("expression");
    return std::make_unique<ExprStmt>(value->location, std::move(value));
}

StmtList Parser::block() {
    skip_newlines();
    consume(TokenKind::indent, "Expected an indented block");
    StmtList statements;
    while (!check(TokenKind::dedent) && !check(TokenKind::end)) {
        statements.push_back(statement());
        skip_newlines();
    }
    consume(TokenKind::dedent, "Expected the block to end");
    return statements;
}

StmtList Parser::suite(const char *what) {
    // Indented block on the following line(s): `if x:` then newline.
    if (check(TokenKind::newline)) {
        expect_newline(what);
        return block();
    }
    // Inline body on the same line: `if x: show "yes"; count += 1`.
    StmtList statements;
    do {
        statements.push_back(statement());
    } while (!last_terminator_was_newline_ && !check(TokenKind::end));
    return statements;
}

ExprPtr Parser::expression() { return or_expression(); }

ExprPtr Parser::or_expression() {
    ExprPtr left = and_expression();
    while (check(TokenKind::or_keyword)) {
        Token op = advance();
        ExprPtr right = and_expression();
        left = std::make_unique<BinaryExpr>(op.location, std::move(left), op.kind, std::move(right));
    }
    return left;
}

ExprPtr Parser::and_expression() {
    ExprPtr left = equality();
    while (check(TokenKind::and_keyword)) {
        Token op = advance();
        ExprPtr right = equality();
        left = std::make_unique<BinaryExpr>(op.location, std::move(left), op.kind, std::move(right));
    }
    return left;
}

ExprPtr Parser::equality() {
    ExprPtr left = comparison();
    while (check(TokenKind::equal_equal) || check(TokenKind::bang_equal)) {
        Token op = advance();
        ExprPtr right = comparison();
        left = std::make_unique<BinaryExpr>(op.location, std::move(left), op.kind, std::move(right));
    }
    return left;
}

ExprPtr Parser::comparison() {
    ExprPtr left = term();
    while (check(TokenKind::less) || check(TokenKind::less_equal) || check(TokenKind::greater) ||
           check(TokenKind::greater_equal)) {
        Token op = advance();
        ExprPtr right = term();
        left = std::make_unique<BinaryExpr>(op.location, std::move(left), op.kind, std::move(right));
    }
    return left;
}

ExprPtr Parser::term() {
    ExprPtr left = factor();
    while (check(TokenKind::plus) || check(TokenKind::minus)) {
        Token op = advance();
        ExprPtr right = factor();
        left = std::make_unique<BinaryExpr>(op.location, std::move(left), op.kind, std::move(right));
    }
    return left;
}

ExprPtr Parser::factor() {
    ExprPtr left = unary();
    while (check(TokenKind::star) || check(TokenKind::slash) || check(TokenKind::percent)) {
        Token op = advance();
        ExprPtr right = unary();
        left = std::make_unique<BinaryExpr>(op.location, std::move(left), op.kind, std::move(right));
    }
    return left;
}

ExprPtr Parser::unary() {
    if (check(TokenKind::minus) || check(TokenKind::not_keyword)) {
        Token op = advance();
        ExprPtr right = unary();
        return std::make_unique<UnaryExpr>(op.location, op.kind, std::move(right));
    }
    return power();
}

// `a ** b` (right-associative) desugars to the built-in pow(a, b).
ExprPtr Parser::power() {
    ExprPtr left = postfix();
    if (check(TokenKind::star_star)) {
        Token op = advance();
        ExprPtr right = unary();
        std::vector<ExprPtr> arguments;
        arguments.push_back(std::move(left));
        arguments.push_back(std::move(right));
        return std::make_unique<CallExpr>(op.location, "pow", std::move(arguments));
    }
    return left;
}

ExprPtr Parser::postfix() {
    ExprPtr expr = primary();
    while (check(TokenKind::left_bracket)) {
        Token bracket = advance();
        ExprPtr index = expression();
        consume(TokenKind::right_bracket, "Need ] after index");
        expr = std::make_unique<IndexExpr>(bracket.location, std::move(expr), std::move(index));
    }
    return expr;
}

ExprPtr Parser::primary() {
    if (check(TokenKind::number)) {
        Token token = advance();
        return std::make_unique<LiteralExpr>(token.location, Value{std::stod(token.lexeme)});
    }
    if (check(TokenKind::text)) {
        Token token = advance();
        return std::make_unique<LiteralExpr>(token.location, Value{token.lexeme});
    }
    if (check(TokenKind::true_keyword)) {
        Token token = advance();
        return std::make_unique<LiteralExpr>(token.location, Value{true});
    }
    if (check(TokenKind::false_keyword)) {
        Token token = advance();
        return std::make_unique<LiteralExpr>(token.location, Value{false});
    }
    if (check(TokenKind::nothing_keyword)) {
        Token token = advance();
        return std::make_unique<LiteralExpr>(token.location, Value{});
    }
    if (check(TokenKind::left_bracket)) {
        Token bracket = advance();
        std::vector<ExprPtr> items;
        if (!check(TokenKind::right_bracket)) {
            do { items.push_back(expression()); } while (match(TokenKind::comma));
        }
        consume(TokenKind::right_bracket, "Need ] after list items");
        return std::make_unique<ListExpr>(bracket.location, std::move(items));
    }
    if (check(TokenKind::left_paren)) {
        advance();
        ExprPtr inner = expression();
        consume(TokenKind::right_paren, "Need ) to close the expression");
        return inner;
    }
    if (check(TokenKind::identifier)) {
        Token name = advance();
        if (check(TokenKind::left_paren)) {
            advance();
            std::vector<ExprPtr> arguments;
            if (!check(TokenKind::right_paren)) {
                do { arguments.push_back(expression()); } while (match(TokenKind::comma));
            }
            consume(TokenKind::right_paren, "Need ) after arguments");
            return std::make_unique<CallExpr>(name.location, name.lexeme, std::move(arguments));
        }
        return std::make_unique<NameExpr>(name.location, name.lexeme);
    }
    fail("Expected a value here", peek().location);
}

void Parser::skip_newlines() {
    while (check(TokenKind::newline)) advance();
}

void Parser::expect_newline(const char *what) {
    // A `;` ends a statement mid-line, so several statements can share a line.
    if (check(TokenKind::semicolon)) {
        advance();
        last_terminator_was_newline_ = false;
        // Allow a trailing `;` right before the line break.
        if (check(TokenKind::newline)) {
            advance();
            last_terminator_was_newline_ = true;
        }
        return;
    }
    if (check(TokenKind::newline) || check(TokenKind::end) || check(TokenKind::dedent)) {
        if (check(TokenKind::newline)) advance();
        last_terminator_was_newline_ = true;
        return;
    }
    fail(std::string{"Expected a new line (or ;) after "} + what, peek().location);
}

bool Parser::match(TokenKind kind) {
    if (!check(kind)) return false;
    advance();
    return true;
}

bool Parser::check(TokenKind kind) const { return peek().kind == kind; }

const Token &Parser::advance() {
    if (!check(TokenKind::end)) ++current_;
    return previous();
}

const Token &Parser::peek() const { return tokens_.at(current_); }

const Token &Parser::previous() const { return tokens_.at(current_ - 1); }

const Token &Parser::consume(TokenKind kind, const std::string &message) {
    if (check(kind)) return advance();
    fail(message + " (found " + std::string{token_name(peek().kind)} + ")", peek().location);
}
}
