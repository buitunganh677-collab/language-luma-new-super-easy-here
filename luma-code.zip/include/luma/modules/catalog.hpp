#pragma once

#include <string_view>
#include <vector>

namespace luma
{

    struct ModuleDescriptor
    {
        std::string_view area;
        std::string_view name;
        std::string_view responsibility;
    };

    namespace modules
    {

#define LUMA_DESCRIPTOR_FUNCTIONS(X) \
    X(core, allocations)             \
    X(core, assertions)              \
    X(core, build_info)              \
    X(core, configuration)           \
    X(core, contracts)               \
    X(core, handles)                 \
    X(core, identifiers)             \
    X(core, source_locations)        \
    X(core, strings)                 \
    X(core, utf8)                    \
    X(core, paths)                   \
    X(core, files)                   \
    X(core, clocks)                  \
    X(core, metrics)                 \
    X(core, tracing)                 \
    X(diagnostic, colors)            \
    X(diagnostic, codes)             \
    X(diagnostic, context)           \
    X(diagnostic, formatter)         \
    X(diagnostic, hints)             \
    X(diagnostic, renderer)          \
    X(diagnostic, reporter)          \
    X(diagnostic, severities)        \
    X(diagnostic, snippets)          \
    X(diagnostic, spans)             \
    X(lex, comments)                 \
    X(lex, delimiters)               \
    X(lex, indentation)              \
    X(lex, keywords)                 \
    X(lex, numbers)                  \
    X(lex, operators)                \
    X(lex, strings)                  \
    X(lex, token_stream)             \
    X(lex, unicode)                  \
    X(lex, whitespace)               \
    X(ast, builders)                 \
    X(ast, cloning)                  \
    X(ast, expressions)              \
    X(ast, formatting)               \
    X(ast, nodes)                    \
    X(ast, program)                  \
    X(ast, statements)               \
    X(ast, validation)               \
    X(ast, visitors)                 \
    X(ast, walking)                  \
    X(parse, blocks)                 \
    X(parse, context)                \
    X(parse, error_recovery)         \
    X(parse, expressions)            \
    X(parse, grammar)                \
    X(parse, precedence)             \
    X(parse, statements)             \
    X(parse, synchronization)        \
    X(parse, token_cursor)           \
    X(parse, validation)             \
    X(bytecode, constants)           \
    X(bytecode, debug_info)          \
    X(bytecode, disassembler)        \
    X(bytecode, emitter)             \
    X(bytecode, layout)              \
    X(bytecode, optimizer)           \
    X(bytecode, serializer)          \
    X(bytecode, verifier)            \
    X(bytecode, writer)              \
    X(runtime, arithmetic)           \
    X(runtime, call_frames)          \
    X(runtime, closures)             \
    X(runtime, collections)          \
    X(runtime, comparisons)          \
    X(runtime, dispatch)             \
    X(runtime, environments)         \
    X(runtime, functions)            \
    X(runtime, garbage_collection)   \
    X(runtime, globals)              \
    X(runtime, internals)            \
    X(runtime, stack)                \
    X(runtime, truthiness)           \
    X(runtime, values)               \
    X(stdlib, conversion)            \
    X(stdlib, io)                    \
    X(stdlib, lists)                 \
    X(stdlib, math)                  \
    X(stdlib, random)                \
    X(stdlib, system)                \
    X(stdlib, text)

#define LUMA_DECLARE_DESCRIPTOR(area, name) ModuleDescriptor area##_##name();
        LUMA_DESCRIPTOR_FUNCTIONS(LUMA_DECLARE_DESCRIPTOR)
#undef LUMA_DECLARE_DESCRIPTOR

    }

    [[nodiscard]] const std::vector<ModuleDescriptor> &module_catalog();

}