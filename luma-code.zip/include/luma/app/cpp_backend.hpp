#pragma once

// Translates a parsed Luma program into a standalone C++23 translation unit.
// The generated code calls straight into the same `luma::rt` / `luma::stdlib`
// runtime the interpreter uses, so compiled and interpreted programs behave
// identically; only the control flow becomes native C++ instead of a
// bytecode loop.

#include <string>

#include "luma/ast/ast.hpp"

namespace luma::codegen
{

    [[nodiscard]] std::string generate_cpp(const Program &program);

}
