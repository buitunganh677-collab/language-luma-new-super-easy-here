#pragma once

#include <memory>
#include <string>
#include <utility>
#include <vector>

#include "luma/core/source.hpp"
#include "luma/lex/token.hpp"
#include "luma/runtime/value.hpp"

namespace luma
{

    class Expr
    {
    public:
        explicit Expr(SourceLocation source_location) : location(source_location) {}
        virtual ~Expr() = default;

        SourceLocation location;
    };

    using ExprPtr = std::unique_ptr<Expr>;

    class LiteralExpr final : public Expr
    {
    public:
        LiteralExpr(SourceLocation source_location, Value initial_value)
            : Expr(source_location), value(std::move(initial_value)) {}

        Value value;
    };

    class NameExpr final : public Expr
    {
    public:
        NameExpr(SourceLocation source_location, std::string initial_name)
            : Expr(source_location), name(std::move(initial_name)) {}

        std::string name;
    };

    class CallExpr final : public Expr
    {
    public:
        CallExpr(SourceLocation source_location, std::string callee_name, std::vector<ExprPtr> call_arguments)
            : Expr(source_location), name(std::move(callee_name)), arguments(std::move(call_arguments)) {}

        std::string name;
        std::vector<ExprPtr> arguments;
    };

    class ListExpr final : public Expr
    {
    public:
        ListExpr(SourceLocation source_location, std::vector<ExprPtr> list_items)
            : Expr(source_location), items(std::move(list_items)) {}

        std::vector<ExprPtr> items;
    };

    class IndexExpr final : public Expr
    {
    public:
        IndexExpr(SourceLocation source_location, ExprPtr index_base, ExprPtr index_value)
            : Expr(source_location), base(std::move(index_base)), index(std::move(index_value)) {}

        ExprPtr base;
        ExprPtr index;
    };

    class UnaryExpr final : public Expr
    {
    public:
        UnaryExpr(SourceLocation source_location, TokenKind operator_kind, ExprPtr operand)
            : Expr(source_location), operation(operator_kind), right(std::move(operand)) {}

        TokenKind operation;
        ExprPtr right;
    };

    class BinaryExpr final : public Expr
    {
    public:
        BinaryExpr(SourceLocation source_location, ExprPtr left_operand, TokenKind operator_kind, ExprPtr right_operand)
            : Expr(source_location), left(std::move(left_operand)), operation(operator_kind), right(std::move(right_operand)) {}

        ExprPtr left;
        TokenKind operation;
        ExprPtr right;
    };

    class Stmt
    {
    public:
        explicit Stmt(SourceLocation source_location) : location(source_location) {}
        virtual ~Stmt() = default;

        SourceLocation location;
    };

    using StmtPtr = std::unique_ptr<Stmt>;
    using StmtList = std::vector<StmtPtr>;

    class LetStmt final : public Stmt
    {
    public:
        LetStmt(SourceLocation source_location, std::string variable_name, ExprPtr initial_value)
            : Stmt(source_location), name(std::move(variable_name)), value(std::move(initial_value)) {}

        std::string name;
        ExprPtr value;
    };

    class AssignStmt final : public Stmt
    {
    public:
        AssignStmt(SourceLocation source_location, std::string variable_name, ExprPtr next_value)
            : Stmt(source_location), name(std::move(variable_name)), value(std::move(next_value)) {}

        std::string name;
        ExprPtr value;
    };

    // `list[index] = value` -- writes into an element of a list.
    class IndexAssignStmt final : public Stmt
    {
    public:
        IndexAssignStmt(SourceLocation source_location, ExprPtr assigned_base, ExprPtr assigned_index, ExprPtr next_value)
            : Stmt(source_location), base(std::move(assigned_base)), index(std::move(assigned_index)),
              value(std::move(next_value)) {}

        ExprPtr base;
        ExprPtr index;
        ExprPtr value;
    };

    class BreakStmt final : public Stmt
    {
    public:
        explicit BreakStmt(SourceLocation source_location) : Stmt(source_location) {}
    };

    class ContinueStmt final : public Stmt
    {
    public:
        explicit ContinueStmt(SourceLocation source_location) : Stmt(source_location) {}
    };

    // `pass` -- does nothing; lets a block stay empty, like in Python.
    class PassStmt final : public Stmt
    {
    public:
        explicit PassStmt(SourceLocation source_location) : Stmt(source_location) {}
    };

    // `import utils` or `import "lib/utils.luma"` -- pulls another Luma file
    // into the program. Resolved (and spliced away) by the program loader
    // before compilation, like Python's module system.
    class ImportStmt final : public Stmt
    {
    public:
        ImportStmt(SourceLocation source_location, std::string module_name)
            : Stmt(source_location), module(std::move(module_name)) {}

        std::string module;
    };

    class ShowStmt final : public Stmt
    {
    public:
        ShowStmt(SourceLocation source_location, ExprPtr displayed_value)
            : Stmt(source_location), value(std::move(displayed_value)) {}

        ExprPtr value;
    };

    // A bare expression used as a statement (e.g. calling `push(list, 1)` on
    // its own line): evaluated for its side effects, result discarded.
    class ExprStmt final : public Stmt
    {
    public:
        ExprStmt(SourceLocation source_location, ExprPtr evaluated_value)
            : Stmt(source_location), value(std::move(evaluated_value)) {}

        ExprPtr value;
    };

    class FuncStmt final : public Stmt
    {
    public:
        FuncStmt(SourceLocation source_location, std::string function_name, std::vector<std::string> parameter_names,
                 StmtList function_body)
            : Stmt(source_location), name(std::move(function_name)), parameters(std::move(parameter_names)),
              body(std::move(function_body)) {}

        std::string name;
        std::vector<std::string> parameters;
        StmtList body;
    };

    class ReturnStmt final : public Stmt
    {
    public:
        ReturnStmt(SourceLocation source_location, ExprPtr returned_value)
            : Stmt(source_location), value(std::move(returned_value)) {}

        bool has_value() const noexcept { return value != nullptr; }
        ExprPtr value;
    };

    class ForStmt final : public Stmt
    {
    public:
        ForStmt(SourceLocation source_location, std::string variable_name, ExprPtr sequence, StmtList loop_body)
            : Stmt(source_location), name(std::move(variable_name)), iterable(std::move(sequence)),
              body(std::move(loop_body)) {}

        std::string name;
        ExprPtr iterable;
        StmtList body;
    };

    // `for i in start to stop [step s]:` -- an inclusive counting loop.
    // Compiled as a plain counter+compare+add loop (no list is built), so it
    // is as fast as a hand-written while loop.
    class CountForStmt final : public Stmt
    {
    public:
        CountForStmt(SourceLocation source_location, std::string variable_name, ExprPtr start_value,
                     ExprPtr stop_value, ExprPtr step_value, StmtList loop_body)
            : Stmt(source_location), name(std::move(variable_name)), start(std::move(start_value)),
              stop(std::move(stop_value)), step(std::move(step_value)), body(std::move(loop_body)) {}

        std::string name;
        ExprPtr start;
        ExprPtr stop;
        ExprPtr step;
        StmtList body;
    };

    class WhileStmt final : public Stmt
    {
    public:
        WhileStmt(SourceLocation source_location, ExprPtr loop_condition, StmtList loop_body)
            : Stmt(source_location), condition(std::move(loop_condition)), body(std::move(loop_body)) {}

        ExprPtr condition;
        StmtList body;
    };

    class WhenStmt final : public Stmt
    {
    public:
        WhenStmt(SourceLocation source_location, ExprPtr predicate, StmtList true_branch, StmtList false_branch)
            : Stmt(source_location), condition(std::move(predicate)), then_branch(std::move(true_branch)),
              otherwise_branch(std::move(false_branch)) {}

        ExprPtr condition;
        StmtList then_branch;
        StmtList otherwise_branch;
    };

    class RepeatStmt final : public Stmt
    {
    public:
        RepeatStmt(SourceLocation source_location, ExprPtr repetitions, StmtList loop_body)
            : Stmt(source_location), count(std::move(repetitions)), body(std::move(loop_body)) {}

        ExprPtr count;
        StmtList body;
    };

    struct Program
    {
        StmtList statements;
    };

}