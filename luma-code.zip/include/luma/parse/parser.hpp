#pragma once

#include <cstddef>
#include <vector>

#include "luma/ast/ast.hpp"
#include "luma/lex/token.hpp"

namespace luma
{

    // Recursive-descent parser for the Python-like, indentation-aware syntax.
    // Both `when`/`otherwise` and `if`/`elif`/`else` spellings are accepted
    // so beginners coming from Python feel at home.
    class Parser
    {
    public:
        explicit Parser(std::vector<Token> tokens);

        [[nodiscard]] Program parse();

    private:
        [[nodiscard]] StmtPtr statement();
        [[nodiscard]] StmtPtr let_statement();
        [[nodiscard]] StmtPtr assignment_statement(Token name);
        [[nodiscard]] StmtPtr show_statement();
        [[nodiscard]] StmtPtr when_statement();
        [[nodiscard]] StmtPtr repeat_statement();
        [[nodiscard]] StmtPtr func_statement();
        [[nodiscard]] StmtPtr return_statement();
        [[nodiscard]] StmtPtr for_statement();
        [[nodiscard]] StmtPtr while_statement();
        [[nodiscard]] StmtPtr until_statement();
        [[nodiscard]] StmtPtr forever_statement();
        [[nodiscard]] StmtPtr import_statement();
        [[nodiscard]] StmtPtr expression_statement();
        [[nodiscard]] StmtList block();
        // A statement body after `:` -- either an indented block on the next
        // line, or one-or-more `;`-separated statements on the same line.
        [[nodiscard]] StmtList suite(const char *what);

        [[nodiscard]] ExprPtr expression();
        [[nodiscard]] ExprPtr or_expression();
        [[nodiscard]] ExprPtr and_expression();
        [[nodiscard]] ExprPtr equality();
        [[nodiscard]] ExprPtr comparison();
        [[nodiscard]] ExprPtr term();
        [[nodiscard]] ExprPtr factor();
        [[nodiscard]] ExprPtr unary();
        [[nodiscard]] ExprPtr power();
        [[nodiscard]] ExprPtr postfix();
        [[nodiscard]] ExprPtr primary();

        void skip_newlines();
        void expect_newline(const char *what);
        [[nodiscard]] bool match(TokenKind kind);
        [[nodiscard]] bool check(TokenKind kind) const;
        [[nodiscard]] const Token &advance();
        [[nodiscard]] const Token &peek() const;
        [[nodiscard]] const Token &previous() const;
        [[nodiscard]] const Token &consume(TokenKind kind, const std::string &message);

        std::vector<Token> tokens_;
        std::size_t current_{0};
        // True when the last statement terminator consumed by expect_newline
        // was a real line break (or dedent/end) rather than a `;`.
        bool last_terminator_was_newline_{true};
    };

}
