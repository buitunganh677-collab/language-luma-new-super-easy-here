#pragma once

#include <cstddef>
#include <string>
#include <unordered_map>
#include <vector>

#include "luma/bytecode/chunk.hpp"
#include "luma/runtime/value.hpp"

namespace luma
{

    // Tree-walking-over-bytecode virtual machine that executes a compiled
    // Luma chunk. Function bodies are executed by recursively running their
    // own (nested) chunk, using the C++ call stack for Luma call frames.
    // Every scope is a single name -> value map; `execute_chunk` only ever
    // looks at the current frame's map plus the outermost (global) map, which
    // matches Luma's simple two-level (local, global) name resolution.
    class VirtualMachine
    {
    public:
        VirtualMachine();

        void run(const Chunk &chunk);

    private:
        struct ForLoop
        {
            ListPtr list;
            std::size_t index{0};
        };

        // Runs `chunk` in a freshly pushed scope and returns the value handed
        // back by `return_value`/`halt` (or `nothing` if the chunk falls off
        // the end without either).
        [[nodiscard]] Value execute_chunk(const Chunk &chunk, std::unordered_map<std::string, Value> initial_scope = {});

        [[nodiscard]] Value pop(const Instruction &instruction);
        void push(Value value);
        [[noreturn]] void runtime_error(const std::string &message, const Instruction &instruction);
        [[nodiscard]] Value *find_variable(const std::string &name);
        [[nodiscard]] Value call_value(Value callee, std::vector<Value> arguments, const Instruction &instruction);

        std::vector<Value> stack_;
        std::vector<std::unordered_map<std::string, Value>> scopes_;
    };

}
