#pragma once

#include <cstddef>
#include <functional>
#include <memory>
#include <string>
#include <variant>
#include <vector>

namespace luma
{

    class Value;
    struct FunctionInfo;

    using ListPtr = std::shared_ptr<std::vector<Value>>;

    // Owns the compiled body of a user-defined function so a function value
    // stays valid regardless of which chunk is currently executing.
    struct FunctionRecord
    {
        std::shared_ptr<const FunctionInfo> info;
    };

    using FunctionPtr = std::shared_ptr<const FunctionRecord>;

    struct NativeRecord
    {
        std::string name;
        std::size_t min_arguments{0};
        std::size_t max_arguments{0}; // 0 means "no upper limit" is stored separately
        bool unlimited{false};
        std::function<Value(std::vector<Value> &)> call;
    };

    using NativePtr = std::shared_ptr<const NativeRecord>;

    class Value
    {
    public:
        using Storage = std::variant<std::monostate, bool, double, std::string, ListPtr, FunctionPtr, NativePtr>;

        Value() = default;
        Value(bool value);
        Value(double value);
        Value(std::string value);
        Value(ListPtr value);
        Value(FunctionPtr value);
        Value(NativePtr value);

        [[nodiscard]] const Storage &storage() const noexcept;
        [[nodiscard]] bool truthy() const;
        [[nodiscard]] std::string display() const;
        [[nodiscard]] std::string type_name() const;
        [[nodiscard]] bool is_number() const;
        [[nodiscard]] double as_number() const;
        [[nodiscard]] bool is_list() const;
        [[nodiscard]] const std::vector<Value> &as_list() const;
        [[nodiscard]] const ListPtr &as_list_ptr() const;
        [[nodiscard]] bool is_text() const;
        [[nodiscard]] const std::string &as_text() const;
        [[nodiscard]] bool is_function() const;
        [[nodiscard]] bool is_native() const;
        [[nodiscard]] const FunctionPtr &as_function() const;
        [[nodiscard]] const NativePtr &as_native() const;

    private:
        Storage storage_;
    };

    bool operator==(const Value &left, const Value &right);

}