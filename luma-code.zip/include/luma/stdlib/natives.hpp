#pragma once

// Native ("built-in") functions shared by the interpreter (`luma run`) and
// the native compiler backend (`luma build`). Keeping one implementation
// means a program behaves the same whether it is interpreted or compiled.

#include <string>
#include <unordered_map>
#include <vector>

#include "luma/runtime/value.hpp"

namespace luma::stdlib
{

    // Every name a Luma program can call without defining it itself, ready to
    // be merged into the interpreter's global scope.
    [[nodiscard]] const std::unordered_map<std::string, Value> &native_globals();

    // Runtime-dispatched entry point used by generated native code: looks up
    // `name` in `native_globals()` and calls it with `arguments`.
    [[nodiscard]] Value call_native(const std::string &name, std::vector<Value> arguments);

}
