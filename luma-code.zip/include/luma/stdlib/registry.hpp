#pragma once

#include <string_view>
#include <vector>

namespace luma
{

    struct StandardLibraryModule
    {
        std::string_view name;
        std::string_view summary;
    };

    [[nodiscard]] const std::vector<StandardLibraryModule> &standard_library_modules();

}