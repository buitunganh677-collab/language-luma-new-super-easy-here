#pragma once

#include <string_view>
#include <vector>

#include "luma/lex/token.hpp"

namespace luma
{

    class Lexer
    {
    public:
        explicit Lexer(std::string_view source);

        [[nodiscard]] std::vector<Token> scan() const;

    private:
        std::string_view source_;
    };

}