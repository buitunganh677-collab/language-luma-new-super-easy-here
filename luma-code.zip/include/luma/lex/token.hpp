#pragma once

#include <string>
#include <string_view>

#include "luma/core/source.hpp"

namespace luma
{

    enum class TokenKind
    {
        end,
        newline,
        indent,
        dedent,
        identifier,
        number,
        text,
        let_keyword,
        show_keyword,
        when_keyword,
        otherwise_keyword,
        repeat_keyword,
        true_keyword,
        false_keyword,
        nothing_keyword,
        and_keyword,
        or_keyword,
        not_keyword,
        if_keyword,
        elif_keyword,
        else_keyword,
        func_keyword,
        return_keyword,
        for_keyword,
        in_keyword,
        to_keyword,
        step_keyword,
        while_keyword,
        until_keyword,
        forever_keyword,
        break_keyword,
        continue_keyword,
        import_keyword,
        pass_keyword,
        left_paren,
        right_paren,
        left_bracket,
        right_bracket,
        colon,
        semicolon,
        comma,
        plus,
        minus,
        star,
        star_star,
        slash,
        percent,
        plus_equal,
        minus_equal,
        star_equal,
        slash_equal,
        percent_equal,
        equal,
        equal_equal,
        bang_equal,
        less,
        less_equal,
        greater,
        greater_equal,
    };

    struct Token
    {
        TokenKind kind;
        std::string lexeme;
        SourceLocation location;
    };

    std::string_view token_name(TokenKind kind);

}