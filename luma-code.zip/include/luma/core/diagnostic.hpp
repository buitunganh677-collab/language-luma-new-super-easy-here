#pragma once

#include <stdexcept>
#include <string>

#include "luma/core/source.hpp"

namespace luma
{

    class Diagnostic final : public std::runtime_error
    {
    public:
        Diagnostic(std::string message, SourceLocation location);

        [[nodiscard]] const SourceLocation &location() const noexcept;

    private:
        SourceLocation location_;
    };

    [[noreturn]] void fail(std::string message, SourceLocation location);

}