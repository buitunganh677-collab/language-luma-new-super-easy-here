#pragma once

#include <cstddef>
#include <filesystem>
#include <string>

namespace luma
{

    struct SourceLocation
    {
        std::size_t line{1};
        std::size_t column{1};
    };

    std::string read_source_file(const std::filesystem::path &path);

}