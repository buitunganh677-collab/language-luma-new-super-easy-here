#pragma once

#include <string_view>

namespace luma
{

    enum class OpCode
    {
        constant,
        load_global,
        define_global,
        assign_global,
        negate,
        logical_not,
        add,
        subtract,
        multiply,
        divide,
        modulo,
        equal,
        not_equal,
        less,
        less_equal,
        greater,
        greater_equal,
        logical_and,
        logical_or,
        print,
        pop,
        make_list,
        index_get,
        index_set,
        make_function,
        call,
        return_value,
        jump_if_false,
        jump,
        begin_repeat,
        repeat_next,
        begin_for,
        for_next,
        pop_repeat,
        pop_for,
        halt,
    };

    std::string_view opcode_name(OpCode opcode);

}