#pragma once

#include <cstddef>
#include <memory>
#include <string>
#include <utility>
#include <vector>

#include "luma/bytecode/opcode.hpp"
#include "luma/core/source.hpp"
#include "luma/runtime/value.hpp"

namespace luma
{

    struct Instruction
    {
        OpCode opcode;
        std::size_t operand_a{0};
        std::size_t operand_b{0};
        SourceLocation location;
    };

    struct FunctionInfo;

    class Chunk
    {
    public:
        [[nodiscard]] std::size_t add_constant(Value value);
        [[nodiscard]] std::size_t add_name(std::string name);
        std::size_t emit(OpCode opcode, std::size_t operand_a, std::size_t operand_b, SourceLocation location);
        void patch(std::size_t instruction, std::size_t operand_a);
        void patch_b(std::size_t instruction, std::size_t operand_b);

        [[nodiscard]] const std::vector<Value> &constants() const noexcept;
        [[nodiscard]] const std::vector<std::string> &names() const noexcept;
        [[nodiscard]] const std::vector<Instruction> &instructions() const noexcept;

        std::size_t add_function(std::vector<std::string> param_names, Chunk body);
        [[nodiscard]] const FunctionInfo &function(std::size_t index) const;
        [[nodiscard]] std::size_t function_count() const noexcept;
        [[nodiscard]] const std::vector<std::shared_ptr<FunctionInfo>> &functions() const noexcept;

    private:
        std::vector<Value> constants_;
        std::vector<std::string> names_;
        std::vector<Instruction> instructions_;
        std::vector<std::shared_ptr<FunctionInfo>> functions_;
    };

    struct FunctionInfo
    {
        std::vector<std::string> param_names;
        Chunk body;
    };

}