# Luma

**A small, readable programming language with an interpreter, a native compiler, and a dedicated Windows editor.**

[English](README.md) | [Tiếng Việt](README.vi.md)

Luma is implemented in modern C++23 and designed around clear, indentation-based syntax. It can execute source files through a bytecode virtual machine or translate them to C++ and produce standalone native executables.

```luma
let name = "Luma"
let tasks = 3

when tasks > 0:
    show "Hello from " + name

    repeat tasks:
        show "One task completed"
otherwise:
    show "Nothing to do"
```

## Highlights

- Readable, Python-inspired indentation
- Interpreter for fast development: `luma run`
- Native compilation to standalone executables: `luma build`
- Numbers, text, booleans, lists, functions, modules, and file I/O
- Conditions and several loop styles
- Shared standard library across interpreted and compiled programs
- Optional SDL2 graphics
- Dedicated Windows editor with syntax highlighting
- English and Vietnamese Windows installer

## Table of Contents

- [Getting Started](#getting-started)
- [Command-Line Usage](#command-line-usage)
- [Language Tour](#language-tour)
- [Loops](#loops)
- [Functions and Modules](#functions-and-modules)
- [Token Reference](#token-reference)
- [Standard Library](#standard-library)
- [Graphics](#graphics)
- [Luma Editor](#luma-editor)
- [Building from Source](#building-from-source)
- [Windows Installer](#windows-installer)
- [Architecture](#architecture)
- [Current Limitations](#current-limitations)

## Getting Started

Luma source files use the `.luma` extension.

Run an example:

```powershell
.\out\luma.exe run .\examples\welcome.luma
```

The explicit `run` command is optional:

```powershell
.\out\luma.exe .\examples\welcome.luma
```

Compile a Luma program to a native executable:

```powershell
.\out\luma.exe build .\examples\welcome.luma
.\examples\welcome.exe
```

Choose a custom output file:

```powershell
.\out\luma.exe build .\examples\welcome.luma -o .\hello.exe
.\hello.exe
```

> Native compilation requires a compatible C++ compiler such as MinGW-w64 `g++`.

## Command-Line Usage

```text
luma <file.luma>
luma run <file.luma>
luma build <file.luma> [-o output]
luma --version
luma --help
```

| Command | Description |
| --- | --- |
| `luma file.luma` | Runs a program using the interpreter. |
| `luma run file.luma` | Explicit form of the interpreter command. |
| `luma build file.luma` | Compiles a program to a native executable. |
| `luma build file.luma -o app.exe` | Compiles with a custom output path. |
| `luma --version` | Displays the installed version. |
| `luma --help` | Displays command-line help. |

`luma build` also writes `<file>.luma.generated.cpp` next to the source file so the generated C++ can be inspected.

## Language Tour

### Values and variables

```luma
let count = 10
let price = 3.14
let message = "Hello"
let enabled = true
let missing = nothing
let values = [10, 20, 30]

count = 20
count += 5
values[0] = 100
```

The main value types are:

| Type | Examples |
| --- | --- |
| Number | `10`, `3.14`, `-5` |
| Text | `"Hello"`, `'Luma'` |
| Boolean | `true`, `false` |
| Empty value | `nothing` |
| List | `[1, 2, 3]` |
| Function | Native or user-defined callable |

### Output and input

```luma
show "Hello, World!"

let name = input("Name: ")
let age = number(input("Age: "))

show "Hello, " + name
show "Next year: " + text(age + 1)
```

### Conditions

Luma supports its own `when` syntax and Python-style alternatives:

```luma
when score >= 50:
    show "Passed"
otherwise:
    show "Failed"
```

```luma
if score >= 80:
    show "Excellent"
elif score >= 50:
    show "Passed"
else:
    show "Failed"
```

### Operators

| Category | Operators |
| --- | --- |
| Arithmetic | `+`, `-`, `*`, `/`, `%`, `**` |
| Assignment | `=`, `+=`, `-=`, `*=`, `/=`, `%=` |
| Comparison | `==`, `!=`, `<`, `<=`, `>`, `>=` |
| Logic | `and`, `or`, `not` |

### Lists

```luma
let numbers = [5, 2, 8]

push(numbers, 1)
sort(numbers)

show numbers
show numbers[0]
show length(numbers)
show sum(numbers)
```

### Comments and blocks

Comments begin with `#`:

```luma
# Full-line comment
let score = 100 # Inline comment
```

Blocks begin after `:` and use spaces for indentation. Tabs are not accepted for indentation.

```luma
if score > 0:
    show "Positive"
    show "Still inside the block"

show "Outside the block"
```

Short bodies and multiple statements may share a line:

```luma
if score > 0: show "Positive"
let a = 1; let b = 2; show a + b
```

## Loops

All loop forms support `break` and `continue`.

| Loop | Purpose |
| --- | --- |
| `repeat N:` | Executes a block a known number of times. |
| `for item in list:` | Iterates over a list. |
| `for i in start to stop:` | Counts inclusively from start to stop. |
| `for i in start to stop step amount:` | Uses a custom positive or negative step. |
| `while condition:` | Runs while a condition is true. |
| `until condition:` | Runs until a condition becomes true. |
| `forever:` | Runs until explicitly stopped with `break`. |

```luma
repeat 3:
    show "Hello"

for value in [10, 20, 30]:
    show value

for number in 1 to 5:
    show number

for number in 10 to 0 step -2:
    show number

let count = 0
while count < 3:
    show count
    count += 1

until count == 5:
    count += 1

forever:
    show "Executed once"
    break
```

Loops may be nested:

```luma
for row in 1 to 3:
    for column in 1 to 3:
        show "Row " + text(row) + ", column " + text(column)
```

The counting loop includes its ending value. `range()` excludes its ending value:

```luma
for number in 1 to 5:       # 1, 2, 3, 4, 5
    show number

for number in range(1, 5):  # 1, 2, 3, 4
    show number
```

## Functions and Modules

### Functions

```luma
func square(number):
    return number ** 2

func greet(name):
    show "Hello, " + name
    return

show square(5)
greet("Luma")
```

### Modules

Create `mathlib.luma`:

```luma
func cube(number):
    return number * number * number
```

Import it from another file:

```luma
import mathlib
show cube(3)
```

Explicit relative paths are also supported:

```luma
import "modules/tools.luma"
```

Modules are resolved relative to the importing file and loaded once per program.

## Token Reference

### Structural tokens

These are generated by the lexer and are not normally written directly:

| Token | Purpose |
| --- | --- |
| `end` | End of source file |
| `newline` | End of line or statement |
| `indent` | Beginning of an indented block |
| `dedent` | End of an indented block |

### Literals and names

| Token | Example |
| --- | --- |
| `identifier` | `name`, `my_value` |
| `number` | `10`, `3.14` |
| `text` | `"Hello"`, `'Hello'` |
| Boolean | `true`, `false` |
| Empty value | `nothing` |

### Keywords

```text
let show when otherwise repeat true false nothing
and or not if elif else func return for in to step
while until forever break continue import pass
```

### Delimiters and operators

```text
( ) [ ] : ; ,
+ - * ** / %
= += -= *= /= %=
== != < <= > >=
```

A standalone `!` is not supported. Use `not` for logical negation and `!=` for inequality.

### Operator precedence

From highest to lowest:

1. Parentheses, literals, names, calls, and indexing
2. Power: `**`
3. Unary operators: `-`, `not`
4. Multiplication, division, remainder: `*`, `/`, `%`
5. Addition and subtraction: `+`, `-`
6. Comparisons: `==`, `!=`, `<`, `<=`, `>`, `>=`
7. Logical AND: `and`
8. Logical OR: `or`

## Standard Library

Built-in functions are globally available in interpreted and compiled programs; no import is required.

### Core and conversion

| Function | Description |
| --- | --- |
| `length(value)` | Returns the length of text or a list. |
| `text(value)` | Converts a value to displayable text. |
| `number(value)` | Converts numeric text to a number. |
| `type_of(value)` | Returns the runtime type name. |

### Mathematics

| Function | Description |
| --- | --- |
| `abs(x)` | Absolute value |
| `sqrt(x)` | Square root |
| `floor(x)` | Rounds downward |
| `ceil(x)` | Rounds upward |
| `round(x)` | Rounds to the nearest integer |
| `pow(base, exponent)` | Raises a value to a power |
| `min(a, b)`, `max(a, b)` | Selects the smaller or larger value |
| `random()` | Random decimal from `0.0` to `1.0` |
| `clamp(value, low, high)` | Restricts a value to a range |
| `sum(list)` | Adds all numbers in a list |

### Lists and ranges

| Function | Description |
| --- | --- |
| `push(list, value)` | Appends a value in place. |
| `pop(list)` | Removes and returns the last value. |
| `sort(list)` | Sorts a list in place. |
| `reverse(list)` | Reverses a list in place. |
| `range(stop)` | Builds `[0, stop)` with a step of 1. |
| `range(start, stop)` | Builds `[start, stop)` with a step of 1. |
| `range(start, stop, step)` | Builds an exclusive range with a custom step. |
| `contains(value, item)` | Checks text or list membership. |
| `find(value, item)` | Returns a zero-based index, or `-1`. |
| `slice(value, start, stop)` | Returns an exclusive slice of text or a list. |

### Text

| Function | Description |
| --- | --- |
| `join(list, separator)` | Joins list values into text. |
| `split(text, separator)` | Splits text into a list. |
| `upper(text)`, `lower(text)` | Changes letter case. |
| `trim(text)` | Removes surrounding whitespace. |
| `replace(text, old, new)` | Replaces all matching text. |
| `starts_with(text, prefix)` | Tests a prefix. |
| `ends_with(text, suffix)` | Tests a suffix. |

### Console, files, and time

| Function | Description |
| --- | --- |
| `input()` / `input(prompt)` | Reads a line from standard input. |
| `read_file(path)` | Reads an entire file as text. |
| `write_file(path, value)` | Replaces a file with the displayed value. |
| `sleep_ms(milliseconds)` | Pauses the current thread. |
| `now_ms()` | Returns the current system time in milliseconds. |

## Graphics

Graphics require SDL2 support when Luma is built.

| Function | Description |
| --- | --- |
| `window_open(title, width, height)` | Opens a window and returns its ID. |
| `window_should_close(id)` | Processes events and reports a close request. |
| `window_clear(id, r, g, b)` | Clears the drawing buffer. |
| `window_set_pixel(id, x, y, r, g, b)` | Draws one pixel. |
| `window_fill_rect(id, x, y, w, h, r, g, b)` | Draws a filled rectangle. |
| `window_draw_line(id, x1, y1, x2, y2, r, g, b)` | Draws a line. |
| `window_present(id)` | Presents the drawing buffer. |
| `window_close(id)` | Destroys the window. |

```luma
let window = window_open("Luma", 640, 480)

if window != -1:
    while not window_should_close(window):
        window_clear(window, 20, 20, 30)
        window_fill_rect(window, 100, 100, 120, 80, 0, 150, 255)
        window_present(window)
        sleep_ms(16)

    window_close(window)
```

Without SDL2, window functions degrade safely and print a one-time warning.

## Luma Editor

Windows builds include `luma-edit.exe`, a lightweight editor dedicated to Luma.

Features:

- Syntax highlighting for keywords, strings, numbers, and comments
- New, Open, Save, and Save As
- UTF-8 file support
- Unsaved-change protection
- Four-space Tab insertion
- Automatic indentation after lines ending in `:`
- Status bar with file state, line, and column
- `F5` to save and run
- `F6` to save and compile
- `.luma` file association through the installer

```powershell
.\out\luma-edit.exe
.\out\luma-edit.exe .\examples\welcome.luma
```

| Shortcut | Action |
| --- | --- |
| `Ctrl+N` | New file |
| `Ctrl+O` | Open file |
| `Ctrl+S` | Save file |
| `F5` | Run program |
| `F6` | Compile program |

## Building from Source

### Requirements

- Windows
- CMake 3.25 or newer
- A C++23 compiler: MinGW-w64 or MSVC
- Optional: SDL2 development files for graphics
- Optional: Inno Setup 6 for creating the installer

### MinGW-w64

```powershell
cmake -S . -B build -G "MinGW Makefiles" -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release
ctest --test-dir build --output-on-failure -C Release
```

Executables are written to `out/`:

```text
out/luma.exe
out/luma-edit.exe
out/luma_tests.exe
```

If SDL2 is installed through MSYS2:

```powershell
pacman -S mingw-w64-x86_64-SDL2
```

Configure the project again after installing SDL2.

## Windows Installer

The repository includes `install.iss` for Inno Setup 6.

Build and test the project first, then compile the installer:

```powershell
cmake --build build --config Release
ctest --test-dir build --output-on-failure -C Release
& "C:\Program Files (x86)\Inno Setup 6\ISCC.exe" ".\install.iss"
```

Output:

```text
installer/luma-setup.exe
```

Installer features:

- English and Vietnamese setup interfaces
- Compiler and editor installation
- Optional system or user PATH registration
- Optional desktop shortcut
- Optional `.luma` file association
- Examples, headers, runtime sources, and generated build configuration
- PATH cleanup during uninstall

## Architecture

Luma source code flows through:

```text
Source -> Lexer -> Parser -> AST
                         |-> Bytecode compiler -> Virtual machine
                         `-> C++ backend -> Native C++ compiler -> Executable
```

| Directory | Responsibility |
| --- | --- |
| `include/luma/` | Public C++ interfaces |
| `src/lex/` | Indentation-aware tokenization |
| `src/parse/` | Recursive-descent parsing |
| `src/ast/` | Abstract syntax tree |
| `src/bytecode/` | Bytecode generation |
| `src/runtime/` | Runtime values, operations, and VM |
| `src/stdlib/` | Shared built-in functions |
| `src/app/` | CLI, native backend, and editor |
| `examples/` | Example Luma programs |
| `tests/` | C++ regression tests |

## Current Limitations

- Native compilation requires a compatible C++ compiler.
- SDL2 is required for visible graphics windows.
- In native mode, functions must currently be declared at the top level.
- Indirect function calls through variables currently work only in interpreted mode.
- Tabs cannot be used for source indentation.

## Examples

- [`examples/welcome.luma`](examples/welcome.luma) — basic syntax
- [`examples/functions.luma`](examples/functions.luma) — functions, lists, and loops
- [`examples/guess_number.luma`](examples/guess_number.luma) — input and control flow
- [`examples/import_demo.luma`](examples/import_demo.luma) — modules
- [`examples/window_demo.luma`](examples/window_demo.luma) — SDL2 graphics

---

Created in Vietnam with a focus on readable syntax, practical native compilation, and an approachable learning experience.
