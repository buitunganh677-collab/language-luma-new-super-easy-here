; Vietnamese installer strings for Luma.
; Loaded after compiler:Default.isl, so untranslated wizard strings keep the
; built-in Inno Setup defaults.

[LangOptions]
LanguageName=Vietnamese
LanguageID=$042A
LanguageCodePage=0

[Messages]
BeveledLabel=Tiếng Việt
ButtonBack=< &Quay lại
ButtonNext=&Tiếp >
ButtonInstall=&Cài đặt
ButtonOK=OK
ButtonCancel=Hủy
ButtonYes=&Có
ButtonNo=&Không
SetupAppTitle=Cài đặt
SetupWindowTitle=Cài đặt - %1
WelcomeLabel1=Chào mừng đến với trình cài đặt [name]
WelcomeLabel2=Trình cài đặt sẽ cài [name/ver] vào máy tính của bạn.%n%nBạn nên đóng các ứng dụng khác trước khi tiếp tục.
FinishedHeadingLabel=Hoàn tất cài đặt [name]
FinishedLabelNoIcons=Trình cài đặt đã hoàn tất cài [name] vào máy tính của bạn.
FinishedLabel=Trình cài đặt đã hoàn tất cài [name] vào máy tính của bạn. Bạn có thể chạy ứng dụng từ các biểu tượng đã tạo.
ExitSetupMessage=Trình cài đặt chưa hoàn tất. Nếu thoát bây giờ, chương trình sẽ chưa được cài đặt.%n%nBạn có chắc muốn thoát không?
