#include <exception>
#include <iostream>

int run_language_tests();

int main()
{
    try
    {
        const auto failures = run_language_tests();
        if (failures == 0)
            std::cout << "All Luma native tests passed.\n";
        return failures == 0 ? 0 : 1;
    }
    catch (const std::exception &error)
    {
        std::cerr << "Test runner failed: " << error.what() << '\n';
        return 1;
    }
}