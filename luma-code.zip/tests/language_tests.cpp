#include <functional>
#include <iostream>
#include <sstream>
#include <string>
#include <utility>

#include "luma/bytecode/compiler.hpp"
#include "luma/core/diagnostic.hpp"
#include "luma/lex/lexer.hpp"
#include "luma/parse/parser.hpp"
#include "luma/runtime/vm.hpp"

namespace
{

    std::string execute(const std::string &source)
    {
        const auto tokens = luma::Lexer{source}.scan();
        const auto program = luma::Parser{tokens}.parse();
        const auto chunk = luma::Compiler{}.compile(program);
        std::ostringstream output;
        auto *const previous = std::cout.rdbuf(output.rdbuf());
        try
        {
            luma::VirtualMachine{}.run(chunk);
        }
        catch (...)
        {
            std::cout.rdbuf(previous);
            throw;
        }
        std::cout.rdbuf(previous);
        return output.str();
    }

    bool check(bool condition, std::string_view name)
    {
        if (condition)
            return true;
        std::cerr << "FAILED: " << name << '\n';
        return false;
    }

}

int run_language_tests()
{
    int failures = 0;
    failures += !check(execute("let value = 2 + 3 * 4\nshow value\n") == "14\n", "arithmetic precedence");
    failures += !check(execute("when false:\n    show \"no\"\notherwise:\n    show \"yes\"\n") == "yes\n", "conditional branch");
    failures += !check(execute("repeat 3:\n    show \"x\"\n") == "x\nx\nx\n", "repeat loop");
    failures += !check(execute("func add(a, b):\n    return a + b\nshow add(2, 3)\n") == "5\n", "function call");
    failures += !check(execute("let total = 0\nfor n in [1, 2, 3]:\n    total = total + n\nshow total\n") == "6\n",
                        "for loop over list");
    failures += !check(execute("let n = 0\nwhile n < 3:\n    show n\n    n = n + 1\n") == "0\n1\n2\n", "while loop");
    failures += !check(execute("func fact(n):\n    when n <= 1:\n        return 1\n    return n * fact(n - 1)\n"
                                "show fact(5)\n") == "120\n",
                        "recursive function");
    failures += !check(execute("if 1 < 2:\n    show \"a\"\nelif 1 > 2:\n    show \"b\"\nelse:\n    show \"c\"\n") ==
                            "a\n",
                        "if/elif/else desugaring");
    failures += !check(execute("let n = 1\nn += 4\nn *= 2\nn -= 3\nshow n\n") == "7\n", "compound assignment");
    failures += !check(execute("show 2 ** 10\n") == "1024\n", "power operator");
    failures += !check(execute("let items = [1, 2, 3]\nitems[1] = 9\nshow items[1]\n") == "9\n", "index assignment");
    failures += !check(execute("for n in [1, 2, 3, 4]:\n    when n == 3:\n        break\n    show n\n") == "1\n2\n",
                        "break in for loop");
    failures += !check(execute("for n in [1, 2, 3]:\n    when n == 2:\n        continue\n    show n\n") == "1\n3\n",
                        "continue in for loop");
    failures += !check(execute("let n = 0\nwhile true:\n    n += 1\n    when n >= 3:\n        break\nshow n\n") ==
                            "3\n",
                        "break in while loop");
    failures += !check(execute("let n = 0\nrepeat 5:\n    n += 1\n    when n == 2:\n        break\nshow n\n") ==
                            "2\n",
                        "break in repeat loop");
    failures += !check(execute("let items = [3, 1, 2]\nsort(items)\nshow items\n") == "[1, 2, 3]\n", "sort builtin");
    failures += !check(execute("let a = 1; let b = 2; show a + b\n") == "3\n", "semicolon separators");
    failures += !check(execute("if 2 > 1: show \"yes\"\nelse: show \"no\"\n") == "yes\n", "inline suite");
    failures += !check(execute("if true: show 1; show 2\nshow 3\n") == "1\n2\n3\n", "inline suite with semicolon");
    failures += !check(execute("when true: pass\nshow 1\n") == "1\n", "pass statement");
    failures += !check(execute("show sum([1, 2, 3])\n") == "6\n", "sum builtin");
    failures += !check(execute("show slice(\"hello\", 1, 3)\n") == "el\n", "slice builtin");
    failures += !check(execute("show replace(\"aaa\", \"a\", \"b\")\n") == "bbb\n", "replace builtin");
    failures += !check(execute("show find([4, 5, 6], 5)\n") == "1\n", "find builtin");
    failures += !check(execute("show trim(\"  hi  \")\n") == "hi\n", "trim builtin");
    failures += !check(execute("show clamp(15, 0, 10)\n") == "10\n", "clamp builtin");
    failures += !check(execute("for i in 1 to 5:\n    show i\n") == "1\n2\n3\n4\n5\n", "counting for loop");
    failures += !check(execute("for i in 10 to 1 step -3:\n    show i\n") == "10\n7\n4\n1\n",
                        "counting for loop with step");
    failures += !check(execute("for i in 1 to 5:\n    when i == 3: continue\n    show i\n") == "1\n2\n4\n5\n",
                        "continue in counting loop");
    failures += !check(execute("let x = 0\nuntil x >= 3:\n    x += 1\nshow x\n") == "3\n", "until loop");
    failures += !check(execute("let n = 0\nforever:\n    n += 1\n    when n == 4: break\nshow n\n") == "4\n",
                        "forever loop with break");

    bool reported = false;
    try
    {
        const auto tokens = luma::Lexer{"when true\n    show \"x\"\n"}.scan();
        static_cast<void>(luma::Parser{tokens}.parse());
    }
    catch (const luma::Diagnostic &)
    {
        reported = true;
    }
    failures += !check(reported, "syntax diagnostic");
    return failures;
}