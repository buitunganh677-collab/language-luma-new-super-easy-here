; ============================================================
; Luma installer (Inno Setup 6+)
; ------------------------------------------------------------
; Build steps:
;   1. Build the project first:  cmake --build build
;      (the installer packs out\luma.exe and out\luma-edit.exe)
;   2. Open this file in Inno Setup Compiler and press Compile,
;      or run:  iscc install.iss
;   3. The result is installer\luma-setup.exe
;
; The installer can add Luma to the SYSTEM PATH (all users,
; needs admin) and/or the current user's PATH, so `luma` works
; from cmd.exe and PowerShell right after installing.
; ============================================================

#define MyAppName "Luma"
#define MyAppVersion "0.2.0"
#define MyAppPublisher "Luma Language"
#define MyAppExeName "luma.exe"
#define MyEditorExeName "luma-edit.exe"

[Setup]
AppId={{7E1B7C52-9F4C-45A3-B3D8-6A2E4B1C0F9D}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\{#MyAppName}
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
OutputDir=installer
OutputBaseFilename=luma-setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
; Lets the user pick "install for all users" (admin) or "just me".
PrivilegesRequired=admin
PrivilegesRequiredOverridesAllowed=dialog
ArchitecturesInstallIn64BitMode=x64compatible
ChangesEnvironment=yes
ChangesAssociations=yes
UninstallDisplayIcon={app}\bin\{#MyAppExeName}

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"
Name: "vietnamese"; MessagesFile: "compiler:Default.isl,installer\languages\Vietnamese.isl"

[CustomMessages]
english.AddSystemPath=Add Luma to the SYSTEM PATH (all users)
english.AddUserPath=Add Luma to the current user's PATH
english.CreateDesktopIcon=Create a desktop icon for Luma Editor
english.AssociateLuma=Open .luma files with Luma Editor
english.OpenEditorNow=Open Luma Editor now
english.TryLumaCommand=Try the luma command (opens a terminal)
vietnamese.AddSystemPath=Thêm Luma vào PATH hệ thống (mọi người dùng)
vietnamese.AddUserPath=Thêm Luma vào PATH của người dùng hiện tại
vietnamese.CreateDesktopIcon=Tạo biểu tượng Luma Editor trên Desktop
vietnamese.AssociateLuma=Mở file .luma bằng Luma Editor
vietnamese.OpenEditorNow=Mở Luma Editor ngay
vietnamese.TryLumaCommand=Thử lệnh luma (mở terminal)

[Tasks]
Name: "addsystempath"; Description: "{cm:AddSystemPath}"; Check: IsAdminInstallMode
Name: "adduserpath"; Description: "{cm:AddUserPath}"; Flags: unchecked
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"
Name: "assoc"; Description: "{cm:AssociateLuma}"

[Files]
; The compiled CLI (build the project with CMake first).
Source: "out\{#MyAppExeName}"; DestDir: "{app}\bin"; Flags: ignoreversion
; The Luma Editor GUI (built as the luma_edit CMake target).
Source: "out\{#MyEditorExeName}"; DestDir: "{app}\bin"; Flags: ignoreversion
; SDL2 runtime, if it sits next to the exe after building (optional).
Source: "out\SDL2.dll"; DestDir: "{app}\bin"; Flags: ignoreversion skipifsourcedoesntexist
; Headers + runtime sources: required by `luma build`, which compiles
; generated C++ together with these files on the user's machine.
Source: "include\*"; DestDir: "{app}\include"; Flags: recursesubdirs ignoreversion
Source: "build\generated\*"; DestDir: "{app}\include"; Flags: recursesubdirs ignoreversion skipifsourcedoesntexist
Source: "src\*"; DestDir: "{app}\src"; Flags: recursesubdirs ignoreversion
; Documentation and sample programs.
Source: "README.md"; DestDir: "{app}"; Flags: ignoreversion
Source: "examples\*"; DestDir: "{app}\examples"; Flags: recursesubdirs ignoreversion
; Installer UI translations.
Source: "installer\languages\*"; DestDir: "{app}\installer\languages"; Flags: recursesubdirs ignoreversion

[Registry]
; SYSTEM PATH (all users) - written only for admin installs.
Root: HKLM; Subkey: "SYSTEM\CurrentControlSet\Control\Session Manager\Environment"; ValueType: expandsz; ValueName: "Path"; ValueData: "{olddata};{app}\bin"; Tasks: addsystempath; Check: NeedsAddSystemPath
; Current user's PATH.
Root: HKCU; Subkey: "Environment"; ValueType: expandsz; ValueName: "Path"; ValueData: "{olddata};{app}\bin"; Tasks: adduserpath; Check: NeedsAddUserPath
; .luma file association -> Luma Editor (double-click opens the editor).
Root: HKA; Subkey: "Software\Classes\.luma"; ValueType: string; ValueName: ""; ValueData: "Luma.Program"; Flags: uninsdeletevalue; Tasks: assoc
Root: HKA; Subkey: "Software\Classes\Luma.Program"; ValueType: string; ValueName: ""; ValueData: "Luma program"; Flags: uninsdeletekey; Tasks: assoc
Root: HKA; Subkey: "Software\Classes\Luma.Program\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\bin\{#MyEditorExeName},0"; Tasks: assoc
Root: HKA; Subkey: "Software\Classes\Luma.Program\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\bin\{#MyEditorExeName}"" ""%1"""; Tasks: assoc

[Icons]
Name: "{group}\Luma Editor"; Filename: "{app}\bin\{#MyEditorExeName}"
Name: "{group}\Luma README"; Filename: "{app}\README.md"
Name: "{group}\Luma Examples"; Filename: "{app}\examples"
Name: "{autodesktop}\Luma Editor"; Filename: "{app}\bin\{#MyEditorExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\bin\{#MyEditorExeName}"; Description: "{cm:OpenEditorNow}"; Flags: postinstall skipifsilent nowait
Filename: "cmd.exe"; Parameters: "/k ""{app}\bin\{#MyAppExeName}"" --version"; Description: "{cm:TryLumaCommand}"; Flags: postinstall skipifsilent unchecked

[Code]
function PathSubKey(RootKey: Integer): string;
begin
  if RootKey = HKEY_LOCAL_MACHINE then
    Result := 'SYSTEM\CurrentControlSet\Control\Session Manager\Environment'
  else
    Result := 'Environment';
end;

{ True when Dir is not yet part of the PATH stored under RootKey. }
function NeedsAddPath(RootKey: Integer; Dir: string): Boolean;
var
  OrigPath: string;
begin
  if not RegQueryStringValue(RootKey, PathSubKey(RootKey), 'Path', OrigPath) then
  begin
    Result := True;
    exit;
  end;
  Result := Pos(';' + Uppercase(Dir) + ';', ';' + Uppercase(OrigPath) + ';') = 0;
end;

function NeedsAddSystemPath: Boolean;
begin
  Result := NeedsAddPath(HKEY_LOCAL_MACHINE, ExpandConstant('{app}\bin'));
end;

function NeedsAddUserPath: Boolean;
begin
  Result := NeedsAddPath(HKEY_CURRENT_USER, ExpandConstant('{app}\bin'));
end;

{ Removes Dir from the PATH stored under RootKey (used at uninstall). }
procedure RemoveFromPath(RootKey: Integer; Dir: string);
var
  OrigPath, NewPath: string;
  Position: Integer;
begin
  if not RegQueryStringValue(RootKey, PathSubKey(RootKey), 'Path', OrigPath) then
    exit;
  NewPath := ';' + OrigPath + ';';
  Position := Pos(';' + Uppercase(Dir) + ';', Uppercase(NewPath));
  if Position = 0 then
    exit;
  Delete(NewPath, Position, Length(Dir) + 1);
  { Strip the sentinel separators we added. }
  if (Length(NewPath) > 0) and (NewPath[1] = ';') then
    Delete(NewPath, 1, 1);
  if (Length(NewPath) > 0) and (NewPath[Length(NewPath)] = ';') then
    Delete(NewPath, Length(NewPath), 1);
  RegWriteExpandStringValue(RootKey, PathSubKey(RootKey), 'Path', NewPath);
end;

procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
var
  BinDir: string;
begin
  if CurUninstallStep = usPostUninstall then
  begin
    BinDir := ExpandConstant('{app}\bin');
    if IsAdminInstallMode then
      RemoveFromPath(HKEY_LOCAL_MACHINE, BinDir);
    RemoveFromPath(HKEY_CURRENT_USER, BinDir);
  end;
end;
